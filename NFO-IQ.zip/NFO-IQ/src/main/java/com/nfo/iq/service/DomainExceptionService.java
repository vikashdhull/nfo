package com.nfo.iq.service;

import java.util.List;

import com.nfo.iq.dto.request.DomainExceptionRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.DomainExceptionResponse;
import com.nfo.iq.dto.response.PageableResponse;

public interface DomainExceptionService {

	ApiResponse<DomainExceptionResponse> createDomain(DomainExceptionRequest domainExceptionRequest);

	ApiResponse<DomainExceptionResponse> getDomainExceptionById(String domainExceptionId);

	ApiResponse<DomainExceptionResponse> updateDomainExceptionById(String domainExceptionId);

	ApiResponse<List<DomainExceptionResponse>> getDomainExceptions();

	PageableResponse<DomainExceptionResponse> getDomainExceptionsWithPagination(int pageNumber, int pageSize,
			String sortBy, String sortDir);
}
