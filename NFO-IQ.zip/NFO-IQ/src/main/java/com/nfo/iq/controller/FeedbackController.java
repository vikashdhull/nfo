package com.nfo.iq.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nfo.iq.dto.request.FeedbackRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.FeedbackResponse;
import com.nfo.iq.service.FeedbackService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/feedbacks")
@Slf4j
public class FeedbackController {

	@Autowired
	FeedbackService feedbackService;

	@PostMapping
	public ResponseEntity<ApiResponse<FeedbackResponse>> saveFeedback(@Valid @RequestBody final FeedbackRequest request,
			Principal principal) {
		log.info("Enter in postFeedback Method present in FeedbackController class");

		ApiResponse<FeedbackResponse> response = feedbackService.saveFeedback(request, principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
