package com.nfo.iq.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nfo.iq.entity.Domain;

public interface DomainRepository extends JpaRepository<Domain, Long> {
	
	final String EXIST_ORGANISATION = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM domain d WHERE d.organization_id=:organisationId";
	
	@Query(value = EXIST_ORGANISATION, nativeQuery = true)
	boolean existOrgInDomain(Long organisationId);
	
	Optional<Domain> findByName(String name);
	
	List<Domain> findByIdIn(List<Long> ids);

}
