package com.nfo.iq.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nfo.iq.dto.request.OrganizationRequest;
import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.OrganizationResponse;
import com.nfo.iq.dto.response.PageableResponse;
import com.nfo.iq.service.OrganizationService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/organization")
@Slf4j
@CrossOrigin(origins = "http://localhost:3000")
public class OrganizationController {

	@Autowired
	private OrganizationService organizationService;

	// @PreAuthorize("hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<ApiResponse<OrganizationResponse>> createOrganization(
			@Valid @RequestBody final OrganizationRequest request) {
		log.info("Enter in createOrganization Method present in OrganizationController class");
		ApiResponse<OrganizationResponse> response = organizationService.createOrganization(request);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	// @PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<OrganizationResponse>> getOrganizationById(@PathVariable("id") final Long id) {
		log.info("Enter in getOrganizationById Method present in OrganizationController class");
		ApiResponse<OrganizationResponse> response = organizationService.getOrganizationById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	// @PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<OrganizationResponse>> updateOrganizationInformtion(
			@Valid @RequestBody final OrganizationRequest request,

			@PathVariable("id") final Long id) {
		log.info("Enter in updateOrganizationInformtion Method present in OrganizationController class");
		ApiResponse<OrganizationResponse> response = organizationService.updateOrganization(id, request);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	// @PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<OrganizationResponse>> deleteOrganizationById(@PathVariable final Long id) {
		log.info("Enter in deleteOrganizationById Method present in OrganizationController class");
		ApiResponse<OrganizationResponse> response = organizationService.deleteOrganizationById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	// @PreAuthorize("hasRole('ADMIN')")
	@GetMapping
	public ResponseEntity<PageableResponse<OrganizationResponse>> getOrganizationsWithPagination(
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getOrganizationsWithPagination Method present in OrganizationController class");

		PageableResponse<OrganizationResponse> response = organizationService.getOrganizationsWithPagination(pageNumber,
				pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	//@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/list")
	public ResponseEntity<ApiResponse<List<OrganizationResponse>>> getOrganizations() {
		log.info("Enter in getOrganizations Method present in OrganizationController class");
		ApiResponse<List<OrganizationResponse>> response = organizationService.getOrganizations();

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	//@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/all")
	public ResponseEntity<ApiResponse<OrganizationResponse>> removeOrganisation(@Valid @RequestBody final RemoveAllRequest request) {
		log.info("Enter in removeOrganisation Method present in OrganizationController class");

		ApiResponse<OrganizationResponse> response = organizationService.removeOrganisations(request);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
