package com.nfo.iq.dto.response;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubcriptionDetailsResponse {
	
	private Boolean paymentStatus;
	
	private String subscriptionType;
	
	private Boolean isEnable;
	
	private LocalDate subscriptionStartDate;

}
