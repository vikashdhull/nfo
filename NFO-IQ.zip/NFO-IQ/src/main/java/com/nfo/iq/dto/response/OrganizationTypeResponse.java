package com.nfo.iq.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizationTypeResponse {
	
	private Long id;
	
	private String name;
}
