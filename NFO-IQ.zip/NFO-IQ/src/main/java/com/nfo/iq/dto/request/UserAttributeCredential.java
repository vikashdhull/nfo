package com.nfo.iq.dto.request;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserAttributeCredential {

	private String type;

	private String value;

}
