package com.nfo.iq.dto.response;

public class DomainExceptionResponse {

}
