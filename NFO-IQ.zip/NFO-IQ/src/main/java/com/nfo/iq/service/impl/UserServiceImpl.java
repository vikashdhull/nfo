package com.nfo.iq.service.impl;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.nfo.iq.dto.request.UserRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.SubcriptionDetailsResponse;
import com.nfo.iq.dto.response.UserResponse;
import com.nfo.iq.entity.User;
import com.nfo.iq.exception.DuplicateResourceException;
import com.nfo.iq.repository.UserRepository;
import com.nfo.iq.service.EmailService;
import com.nfo.iq.service.UserService;
import com.nfo.iq.utility.Constants;
import com.nfo.iq.utility.SubscriptionType;
import com.nfo.iq.utility.Utility;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

	@Autowired
	private Keycloak keycloak;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Value("${keycloak.realm}")
	private String realm;

	@Value("${keycloak.client.id}")
	private String client;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	@Autowired
	private EmailService emailService;

	@Override
	public ApiResponse<UserResponse> createUser(UserRequest userRequest) {

		ApiResponse<UserResponse> response = new ApiResponse<>();

		Optional<User> existByUserName = userRepository.findByUsername(userRequest.getEmail());
		Optional<User> existUserByEmail = userRepository.findByEmail(userRequest.getEmail());
		Optional<User> existUserByPhone = userRepository.findByMobileNumber(userRequest.getMobileNumber());

		if (existByUserName.isPresent()) {
			return utility.errorResponse(response, HttpStatus.CONFLICT, "user.create.error.message");
		} else if (existUserByEmail.isPresent()) {
			return utility.errorResponse(response, HttpStatus.CONFLICT, "user.email.create.error.message");
		} else if (existUserByPhone.isPresent()) {
			return utility.errorResponse(response, HttpStatus.CONFLICT, "user.phone.create.error.message");
		} else {

			Response response2 = createUserInKeycloak(userRequest);
			if (!Objects.equals(201, response2.getStatus())) {
				return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "user.create.error");
			}

			//String userId = response2.getLocation().getPath().replaceAll(".*/([^/]+)$", "$1");
			
			String userId = CreatedResponseUtil.getCreatedId(response2);

			userRequest.setPassword(passwordEncoder.encode(userRequest.getPassword()));

			User user = dtoToEntity(userRequest);

			user.setId(userId);

			UserRepresentation representation = getUserResource().get(userId).toRepresentation();

			user.setIsEnable(representation.isEnabled());

			User savedUser = userRepository.save(user);

			utility.addNotification(savedUser, Constants.NOTIFICATION_WELCOME);

			UserResponse newDto = entityToDto(savedUser);

			response.setData(newDto);
			response.setResult(true);
			response.setMessage(env.getProperty("user.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());
			return response;

		}

	}

	private Response createUserInKeycloak(UserRequest userRequest) {
		UserRepresentation userRepresentation = new UserRepresentation();
		userRepresentation.setEnabled(true);

		userRepresentation.setUsername(userRequest.getEmail());
		userRepresentation.setEmail(userRequest.getEmail());
		
		
		userRepresentation.setEmailVerified(true);

		CredentialRepresentation credentialRepresentation = new CredentialRepresentation();

		credentialRepresentation.setValue(userRequest.getPassword());
		credentialRepresentation.setTemporary(false);
		credentialRepresentation.setType(CredentialRepresentation.PASSWORD);
		credentialRepresentation.setUserLabel("My password");

		List<CredentialRepresentation> credentialList = new ArrayList<>();
		credentialList.add(credentialRepresentation);
		userRepresentation.setCredentials(credentialList);

		Map<String, List<String>> attributes = new HashMap<>();

		List<String> list = new ArrayList<>();

		list.add(userRequest.getMobileNumber());

		attributes.put(Constants.MOBILE, list);

		List<String> subscription = new ArrayList<>();

		Boolean paymentStatus = userRequest.getPaymentStatus();
		if (Boolean.TRUE.equals(paymentStatus)) {
			subscription.add(SubscriptionType.PAID.toString());
		} else {
			subscription.add(SubscriptionType.FREE.toString());
		}
		attributes.put(Constants.SUBSCRIPTION_TYPE, subscription);

		userRepresentation.setAttributes(attributes);

		UsersResource usersResource = getUserResource();
		
		return usersResource.create(userRepresentation);
	}

	@Scheduled(cron = "0 0 0 * * *", zone = "UTC")
	private void checkFreeTrialExpirations() {
		LocalDate today = LocalDate.now();
		List<User> freeTrialUser = userRepository.findBySubscriptionTypeAndIsEnable(SubscriptionType.FREE, true);

		// List<UserRepresentation> userRepresentations =
		// getUserResource().searchByAttributes("subscriptionType=FREE");

		// List<UserRepresentation> freeTrialUsers =
		// userRepresentations.stream().filter(u -> !u.isEnabled()).toList();

		for (User user : freeTrialUser) {

			int freeTrialDuration = 7;

			int subscribedDays = Period.between(user.getSubscriptionStartDate(), today).getDays();

			if (subscribedDays > freeTrialDuration) {
				String userId = user.getId();
				UserResource userResource = getUserResource().get(userId);

				UserRepresentation representation = userResource.toRepresentation();

				String mobile = representation.firstAttribute(Constants.MOBILE);

				Map<String, List<String>> attributes = new HashMap<>();

				List<String> subscription = new ArrayList<>();
				subscription.add(SubscriptionType.EXPIRED.toString());
				attributes.put(Constants.SUBSCRIPTION_TYPE, subscription);

				List<String> mList = new ArrayList<>();
				mList.add(mobile);
				attributes.put(Constants.MOBILE, mList);

				representation.setAttributes(attributes);

				userResource.update(representation);
				user.setSubscriptionType(SubscriptionType.EXPIRED);
				userRepository.save(user);
			}
		}
	}

	private UsersResource getUserResource() {
		RealmResource realm1 = keycloak.realm(realm);
		return realm1.users();
	}

	@Override
	public UserRepresentation getUsersById(String userId) {

		return getUserResource().get(userId).toRepresentation();
	}

	@Override
	public ApiResponse<UserResponse> getUserById(String userId) {
		ApiResponse<UserResponse> response = new ApiResponse<>();
		try {
			Optional<User> userDetails = userRepository.findById(userId);
			UserRepresentation representation = getUserResource().get(userId).toRepresentation();

			if (userDetails.isPresent() && Objects.equals(representation.getId(), userId)) {

				User user = userDetails.get();

				response.setMessage(env.getProperty("user.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				UserResponse userResponse = entityToDto(user);
				response.setData(userResponse);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getUserById Method present in UserServiceImpl class{}", exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private UserResponse entityToDto(User user) {

		UserResponse userResponse = new UserResponse();

		userResponse.setId(user.getId());

		userResponse.setUsername(user.getUsername());
		userResponse.setEmail(user.getEmail());
		userResponse.setIsEmailVerified(user.getIsEmailVerified());
		userResponse.setPaymentStatus(user.getPaymentStatus());
		userResponse.setSubscriptionType(user.getSubscriptionType().toString());

		String mobileNumber = user.getMobileNumber();

		if (mobileNumber == null) {
			user.setMobileNumber(null);
		} else {

			userResponse.setMobileNumber(user.getMobileNumber());
		}

		userResponse.setMobileNumber(user.getMobileNumber());

		userResponse.setIsEnable(user.getIsEnable());
		userResponse.setCreatedDate(user.getCreatedDate());
		userResponse.setUpdatedDate(user.getUpdatedDate());

		return userResponse;
	}

	private User dtoToEntity(UserRequest userRequest) {

		User user = new User();
		user.setUsername(userRequest.getEmail());

		user.setEmail(userRequest.getEmail());
		user.setIsEmailVerified(userRequest.getIsEmailVerified());
		Boolean paymentStatus = userRequest.getPaymentStatus();
		if (Boolean.TRUE.equals(paymentStatus)) {
			user.setSubscriptionType(SubscriptionType.PAID);
		} else {
			user.setSubscriptionType(SubscriptionType.FREE);
		}
		user.setSubscriptionStartDate(LocalDate.now());
		user.setPaymentStatus(userRequest.getPaymentStatus());
		String mobileNumber = userRequest.getMobileNumber();

		if (mobileNumber.length() == 0) {
			user.setMobileNumber(null);
		} else {

			user.setMobileNumber(userRequest.getMobileNumber());
		}

		return user;
	}

	@Override
	public ApiResponse<UserResponse> forgotPassword(String username) {
		ApiResponse<UserResponse> response = new ApiResponse<>();

		try {
			UsersResource userResource = getUserResource();
			List<UserRepresentation> representationList = userResource.search(username, true);

			UserRepresentation userRepresentation = representationList.stream().findFirst().orElse(null);

			if (userRepresentation != null) {
				if(Boolean.FALSE.equals(userRepresentation.isEnabled()))
				{
					return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "user.disable.action.message");
				}
				UserResource resource = userResource.get(userRepresentation.getId());
				List<String> action = new ArrayList<>();
				action.add(Constants.UPDATE_PASSWORD);
				resource.executeActionsEmail(action);

				response.setMessage(env.getProperty("forgot.password.link.send"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}

		} catch (UsernameNotFoundException ex) {

			response.setMessage(ex.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<UserResponse> updateEmailById(String userId, String email) {
		ApiResponse<UserResponse> response = new ApiResponse<>();

		Optional<User> existUserByEmail = userRepository.findByEmail(email);

		if (existUserByEmail.isPresent()) {
			return utility.errorResponse(response, HttpStatus.CONFLICT, "user.email.create.error.message");
		}
		UsersResource usersResource = getUserResource();

		List<UserRepresentation> searchByEmail = usersResource.searchByEmail(email, null);

		if (!searchByEmail.isEmpty()) {
			throw new DuplicateResourceException(env.getProperty("user.email.create.error.message"));
		}

		UserResource userResource = usersResource.get(userId);
		UserRepresentation userRepresentation = new UserRepresentation();
		userRepresentation.setUsername(email);
		userRepresentation.setEmail(email);
		userResource.update(userRepresentation);

		Optional<User> findById = userRepository.findById(userId);

		if (findById.isPresent()) {
			User user = findById.get();
			user.setUsername(email);
			user.setEmail(email);
			userRepository.save(user);
		}

		response.setMessage(env.getProperty("email.reset.successful.message"));
		response.setResult(true);
		response.setStatus(HttpStatus.OK.value());
		return response;
	}

	@Override
	public ApiResponse<UserResponse> updatePassword(String userId, String password) {

		ApiResponse<UserResponse> response = new ApiResponse<>();
		try {
			UsersResource usersResource = getUserResource();
			UserResource userResource = usersResource.get(userId);

			CredentialRepresentation credentialRepresentation = new CredentialRepresentation();

			credentialRepresentation.setType(CredentialRepresentation.PASSWORD);
			credentialRepresentation.setTemporary(false);
			credentialRepresentation.setValue(password);
			userResource.resetPassword(credentialRepresentation);

			response.setMessage(env.getProperty("password.reset.successful.message"));
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());
			return response;
		} catch (Exception e) {
			log.error("UserServiceImpl:updatePassword: Exception occurred with error message = " + e.getMessage());
			response.setMessage("Password not set");
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<UserResponse> updateMobile(String userId, String mobile) {
		ApiResponse<UserResponse> response = new ApiResponse<>();

		Optional<User> findById = userRepository.findById(userId);
		if (findById.isPresent()) {

			User user = findById.get();
			Optional<User> findByMobileNumber = userRepository.findByMobileNumber(mobile);

			if (findByMobileNumber.isPresent() && !Objects.equals(user.getMobileNumber(), mobile)) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "user.phone.create.error.message");
			}

			UsersResource usersResource = getUserResource();
			UserResource userResource = usersResource.get(userId);

			UserRepresentation userRepresentation = userResource.toRepresentation();
			String subscriptionType = userRepresentation.firstAttribute(Constants.SUBSCRIPTION_TYPE);

			Map<String, List<String>> attributes = new HashMap<>();
			List<String> list = new ArrayList<>();
			list.add(mobile);

			attributes.put(Constants.MOBILE, list);
			List<String> aList = new ArrayList<>();
			aList.add(subscriptionType);
			userRepresentation.setAttributes(attributes);
			attributes.put(Constants.SUBSCRIPTION_TYPE, aList);
			userResource.update(userRepresentation);

			user.setMobileNumber(mobile);
			userRepository.save(user);

			response.setMessage(env.getProperty("mobile.reset.successful.message"));
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());
			return response;
		} else {
			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
		}

	}

	@Override
	public ApiResponse<UserResponse> disableUser(String userId) {

		ApiResponse<UserResponse> response = new ApiResponse<>();
		try {
			Optional<User> findById = userRepository.findById(userId);

			if (findById.isPresent()) {
				User user = findById.get();
				UserResource userResource = getUserResource().get(userId);

				UserRepresentation representation = userResource.toRepresentation();
				representation.setEnabled(false);
				userResource.update(representation);
				user.setIsEnable(false);
				userRepository.save(user);

				emailService.sendEmail(representation.getEmail(), Constants.ACCOUNT_DEACTIVATION, Constants.DISABLE_USER_BODY_STRING);

				response.setMessage(env.getProperty("user.disable.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());

				return response;

			} else {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}
		} catch (Exception e) {
			log.error("UserServiceImpl:disableUser: Exception occurred with error message = " + e.getMessage());
			response.setMessage(env.getProperty("user.disable.operation.failed"));
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<SubcriptionDetailsResponse> getUserSubcriptionDetails(String userId) {
		ApiResponse<SubcriptionDetailsResponse> response = new ApiResponse<>();

		SubcriptionDetailsResponse subcriptionDetails = new SubcriptionDetailsResponse();

		Optional<User> findById = userRepository.findById(userId);
		if (findById.isPresent()) {
			User user = findById.get();
			UserResource userResource = getUserResource().get(userId);

			UserRepresentation representation = userResource.toRepresentation();

			Optional<String> findSubscription = representation.getAttributes().get(Constants.SUBSCRIPTION_TYPE).stream()
					.findFirst();

			String subscriptionType = findSubscription.isPresent() ? findSubscription.get() : null;

			subcriptionDetails.setPaymentStatus(user.getPaymentStatus());
			subcriptionDetails.setIsEnable(representation.isEnabled());
			subcriptionDetails.setSubscriptionType(subscriptionType);
			subcriptionDetails.setSubscriptionStartDate(user.getSubscriptionStartDate());

			response.setData(subcriptionDetails);

			response.setMessage(env.getProperty("subscription.details.fetch.success.message"));
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());
			return response;

		} else {

			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
		}
	}

	@Override
	public ApiResponse<UserResponse> enableUser(String userId) {
		ApiResponse<UserResponse> response = new ApiResponse<>();

		Optional<User> findById = userRepository.findById(userId);

		if (findById.isPresent()) {
			User user = findById.get();
			UserResource userResource = getUserResource().get(userId);

			UserRepresentation representation = userResource.toRepresentation();
			representation.setEnabled(true);
			userResource.update(representation);
			user.setIsEnable(true);
			userRepository.save(user);
			response.setMessage(env.getProperty("user.enable.success.message"));
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());
			return response;

		} else {

			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
		}
	}
}
