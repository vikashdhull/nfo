package com.nfo.iq.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nfo.iq.entity.UserControlURL;

public interface UserControlURLRepository extends JpaRepository<UserControlURL, Long> {
	
	final String TRUSTED_URL = "SELECT * FROM user_control_url uc WHERE uc.user_id = :id and uc.webpage_url LIKE '%' || :webPageUrl || '%'";
	
	Optional<UserControlURL> findByUserIdAndWebpageURL(String id, String webPageUrl);
	
	Optional<UserControlURL> findByIdAndUserId(Long id, String userId);
	
	List<UserControlURL> findByIdInAndUserId(List<Long> ids, String userId);

	Page<UserControlURL> findByUserId(String userId, Pageable pageable);
	
	@Query(value = TRUSTED_URL, nativeQuery = true)
	Optional<UserControlURL> findTrustedUrl(String id, String webPageUrl);

}
