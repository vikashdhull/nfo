package com.nfo.iq.service;

import com.nfo.iq.dto.request.FeedbackRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.FeedbackResponse;

public interface FeedbackService {
	
	ApiResponse<FeedbackResponse> saveFeedback(FeedbackRequest feedbackRequest, String userId);

}
