package com.nfo.iq.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nfo.iq.dto.request.LoginRequest;
import com.nfo.iq.dto.request.TokenRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.LoginResponse;
import com.nfo.iq.service.LoginService;
import com.nfo.iq.service.impl.UserServiceImpl;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/auth")
@Slf4j
@CrossOrigin(origins = "http://localhost:3000")
public class LoginController {

	@Autowired
	LoginService loginService;

	@Autowired
	UserServiceImpl userService;

	@PostMapping("/login")
	public ResponseEntity<ApiResponse<LoginResponse>> login(@RequestBody LoginRequest request) {
		log.info("Enter in login Method present in LoginController class");
		ApiResponse<LoginResponse> response = loginService.login(request);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PostMapping("/logout/{username}")
	public ResponseEntity<ApiResponse<LoginResponse>> logout(@PathVariable("username") final String username) {
		log.info("Enter in logout Method present in LoginController class");
		
		ApiResponse<LoginResponse> response = loginService.logout(username);
		
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@PostMapping("/refreshToken")
	public ResponseEntity<ApiResponse<LoginResponse>> generateTokenFromRefreshToken(@RequestBody TokenRequest request) {
		log.info("Enter in generateTokenFromRefreshToken Method present in LoginController class");
		ApiResponse<LoginResponse> response = loginService.generateTokenFromRefreshToken(request);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
