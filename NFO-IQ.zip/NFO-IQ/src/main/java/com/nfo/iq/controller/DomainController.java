package com.nfo.iq.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nfo.iq.dto.request.DomainRequest;
import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.DomainResponse;
import com.nfo.iq.dto.response.PageableResponse;
import com.nfo.iq.service.DomainService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/domains")
@Slf4j
@CrossOrigin(origins = "http://localhost:3000")
public class DomainController {

	@Autowired
	private DomainService domainService;

	// @PreAuthorize("hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<ApiResponse<DomainResponse>> createDomain(@Valid @RequestBody final DomainRequest request) {
		log.info("Enter in createDomain Method present in DomainController class");
		ApiResponse<DomainResponse> response = domainService.createDomain(request);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	// @PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<DomainResponse>> getDomainById(@PathVariable("id") final Long id) {
		log.info("Enter in getDomainById Method present in DomainController class");
		ApiResponse<DomainResponse> response = domainService.getDomainById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	// @PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<DomainResponse>> updateDomainInformtion(
			@Valid @RequestBody final DomainRequest request, @PathVariable("id") final Long id) {
		log.info("Enter in updateDomainInformtion Method present in DomainController class");
		ApiResponse<DomainResponse> response = domainService.updateDomain(id, request);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	// @PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<DomainResponse>> deleteDomainById(@PathVariable final Long id) {
		log.info("Enter in deleteDomainById Method present in DomainController class");
		ApiResponse<DomainResponse> response = domainService.deleteDomainById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	// @PreAuthorize("hasRole('ADMIN')")
	@GetMapping
	public ResponseEntity<PageableResponse<DomainResponse>> getDomainsWithPagination(
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getDomainsWithPagination Method present in DomainController class");

		PageableResponse<DomainResponse> response = domainService.getDomainsWithPagination(pageNumber, pageSize, sortBy,
				sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	// @PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/list")
	public ResponseEntity<ApiResponse<List<DomainResponse>>> getOrganizationTypes() {
		log.info("Enter in getDomains Method present in DomainController class");
		ApiResponse<List<DomainResponse>> response = domainService.getDomains();

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	// @PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/all")
	public ResponseEntity<ApiResponse<DomainResponse>> deleteDomains(
			@Valid @RequestBody final RemoveAllRequest request) {
		log.info("Enter in deleteDomains Method present in DomainController class");

		ApiResponse<DomainResponse> response = domainService.deleteDomains(request);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
