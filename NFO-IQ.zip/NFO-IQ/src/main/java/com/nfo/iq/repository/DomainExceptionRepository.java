package com.nfo.iq.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nfo.iq.entity.DomainExceptions;

public interface DomainExceptionRepository extends JpaRepository<DomainExceptions, Long> {
	
	final String EXIST_DOMAIN_TYPE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM domain_exception de WHERE de.domain_id=:domainId";
	
	@Query(value = EXIST_DOMAIN_TYPE, nativeQuery = true)
	boolean existDomainInDomainException(Long domainId);
	
	List<DomainExceptions> findByDomainId(Long id);
	
	

}
