package com.nfo.iq.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(value = Include.NON_NULL)
public class UserNotificationResponse {
	
	private Long id;
	
	private String email;
	
	private String title;
	
	private String message;
	
	private String description;
	
	private Boolean isView;

}
