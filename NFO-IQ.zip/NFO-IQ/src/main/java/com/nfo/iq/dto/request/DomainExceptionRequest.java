package com.nfo.iq.dto.request;

public class DomainExceptionRequest {

}
