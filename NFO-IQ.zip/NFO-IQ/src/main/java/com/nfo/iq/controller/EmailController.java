package com.nfo.iq.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nfo.iq.dto.request.VerifyEmailRequest;
import com.nfo.iq.dto.request.VerifyOtpRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.VerifyEmailResponse;
import com.nfo.iq.service.EmailService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/emails")
@Slf4j
public class EmailController {
	
	@Autowired
	private EmailService emailService;
	
	@PostMapping
	public ResponseEntity<ApiResponse<VerifyEmailResponse>> sendEmailOtp(@Valid @RequestBody final VerifyEmailRequest request) {
		log.info("Enter in sendEmailOtp Method present in EmailController class");

		ApiResponse<VerifyEmailResponse> response = emailService.sendEmailOtp(request);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@PutMapping
	public ResponseEntity<ApiResponse<VerifyEmailResponse>> verifyEmailOtp(@Valid @RequestBody final VerifyOtpRequest request) {
		log.info("Enter in verifyEmailOtp Method present in EmailController class");

		ApiResponse<VerifyEmailResponse> response = emailService.verifyEmailOtp(request);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	

}
