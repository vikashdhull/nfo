package com.nfo.iq.utility;

public class MessageConstants {

    public static final String REMOVE_WWW = "www.";
    public static final String REMOVE_HTTP = "http://www.";
    public static final String REMOVE_HTTPS = "https://www.";
    
    private MessageConstants() { }
}
