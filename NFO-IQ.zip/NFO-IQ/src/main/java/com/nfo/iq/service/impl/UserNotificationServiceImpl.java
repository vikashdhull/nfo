package com.nfo.iq.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.UserNotificationResponse;
import com.nfo.iq.entity.Notification;
import com.nfo.iq.entity.UserNotification;
import com.nfo.iq.repository.UserNotificationRepository;
import com.nfo.iq.service.UserNotificationService;
import com.nfo.iq.utility.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserNotificationServiceImpl implements UserNotificationService {

	@Autowired
	private UserNotificationRepository userNotificationRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	@Override
	public ApiResponse<UserNotificationResponse> readNotification(Long notificationId) {
		ApiResponse<UserNotificationResponse> response = new ApiResponse<>();
		try {
			Optional<UserNotification> findById = userNotificationRepository.findById(notificationId);

			if (findById.isPresent()) {
				UserNotification userNotification = findById.get();

				userNotification.setIsView(true);

				UserNotification savedUserNotification = userNotificationRepository.save(userNotification);

				response.setData(entityToDto(savedUserNotification));
				response.setMessage(env.getProperty("notification.update.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());

				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "notification.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error("UserNotificationServiceImpl::Exception Occured in readNotification Method present.{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<UserNotificationResponse>> getAllNotificationByUser(String userId) {
		ApiResponse<List<UserNotificationResponse>> response = new ApiResponse<>();
		try {

			List<UserNotification> userNotifications = userNotificationRepository.findByUserId(userId);
			List<UserNotificationResponse> userNotificationResponse = userNotifications.stream().map(this::entityToDto)
					.toList();

			if (!userNotificationResponse.isEmpty()) {
				response.setMessage(env.getProperty("notification.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(userNotificationResponse);
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "notification.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error(
					"Exception Occured in getAllNotificationByUser Method present in UserNotificationServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<UserNotificationResponse> removeNotification(Long id) {
		ApiResponse<UserNotificationResponse> response = new ApiResponse<>();
		try {
			Optional<UserNotification> findById = userNotificationRepository.findById(id);

			if (findById.isPresent()) {
				UserNotification userNotification = findById.get();

				userNotificationRepository.delete(userNotification);

				response.setMessage(env.getProperty("notification.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "notification.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error("Exception Occured in removeNotification Method present in UserNotificationServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private UserNotificationResponse entityToDto(UserNotification userNotification) {
		UserNotificationResponse userNotificationResponse = new UserNotificationResponse();

		userNotificationResponse.setId(userNotification.getId());
		userNotificationResponse.setEmail(userNotification.getUser().getEmail());

		Notification notification = userNotification.getNotification();

		userNotificationResponse.setTitle(notification.getTitle());
		String notificationMessage = notification.getMessage();

		if (notificationMessage == null) {
			userNotificationResponse.setMessage(null);
		} else {
			userNotificationResponse.setMessage(notification.getMessage());
		}
		userNotificationResponse.setDescription(notification.getDescription());
		userNotificationResponse.setIsView(userNotification.getIsView());

		return userNotificationResponse;
	}

}
