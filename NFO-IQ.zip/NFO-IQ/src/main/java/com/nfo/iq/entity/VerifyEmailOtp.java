package com.nfo.iq.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "verify_email_otp")
@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VerifyEmailOtp {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(columnDefinition = "serial")
	private Long id;
	
	private String otp;
	
	private String email;
	
	@Column(name = "expiry_date")
	private LocalDateTime expiryDate;

	public VerifyEmailOtp(String otp, String email) {
		this.otp = otp;
		this.email = email;
		this.expiryDate=LocalDateTime.now().plusMinutes(5);
		
	}

}
