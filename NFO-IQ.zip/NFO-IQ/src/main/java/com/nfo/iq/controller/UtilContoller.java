package com.nfo.iq.controller;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/ping")
@Slf4j
public class UtilContoller {
	
	@GetMapping
	public ResponseEntity<?> ping() {
		log.info("Ping API called");
		String response =  "Ping Api called : "+ new Date().toString();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}	
}
