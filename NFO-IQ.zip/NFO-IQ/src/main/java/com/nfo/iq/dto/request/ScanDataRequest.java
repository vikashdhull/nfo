package com.nfo.iq.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ScanDataRequest {
	
	private String scanData;
	
	private String type;

}
