package com.nfo.iq.dto.request;

import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class UpdateUserMobileDto {
	
	@Pattern(regexp="(^$|\\d{10})", message = "Invalid Phone number")
	private String mobileNumber;
}
