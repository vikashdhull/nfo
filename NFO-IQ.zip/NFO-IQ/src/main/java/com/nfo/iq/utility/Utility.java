package com.nfo.iq.utility;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.PageableResponse;
import com.nfo.iq.entity.Notification;
import com.nfo.iq.entity.User;
import com.nfo.iq.entity.UserNotification;
import com.nfo.iq.exception.ResourceNotFoundException;
import com.nfo.iq.repository.NotificationRepository;
import com.nfo.iq.repository.UserNotificationRepository;

@Component
public class Utility {

	@Autowired
	public Environment env;

	@Autowired
	private NotificationRepository notificationRepository;

	@Autowired
	private UserNotificationRepository userNotificationRepository;

	private Random random;

	public <U> ApiResponse<U> errorResponse(ApiResponse<U> response, HttpStatus status, String errorMessage) {
		response.setResult(false);
		response.setMessage(env.getProperty(errorMessage));
		response.setStatus(status.value());
		return response;
	}

	public <U> PageableResponse<U> pageableErrorResponse(PageableResponse<U> response, HttpStatus status,
			String errorMessage) {
		response.setResult(false);
		response.setMessage(env.getProperty(errorMessage));
		response.setStatus(status.value());
		return response;
	}

	@Transactional
	public void addNotification(User user, Long notificationId) {

		Optional<Notification> findNotification = notificationRepository.findById(notificationId);

		if (findNotification.isEmpty()) {
			throw new ResourceNotFoundException(env.getProperty("notification.fetch.error.message"));
		}
		UserNotification userNotification = new UserNotification();

		userNotification.setNotification(findNotification.get());
		userNotification.setIsView(false);
		userNotification.setUser(user);

		userNotificationRepository.save(userNotification);

	}

	public String generateOtp() {
		try {
			random = SecureRandom.getInstanceStrong();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		int otp = 100000 + random.nextInt(900000);
		return String.valueOf(otp);

	}

}
