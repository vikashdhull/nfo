package com.nfo.iq.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.net.InternetDomainName;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.entity.Domain;
import com.nfo.iq.entity.DomainExceptions;
import com.nfo.iq.entity.Organization;
import com.nfo.iq.entity.OrganizationType;
import com.nfo.iq.entity.ProgramFile;
import com.nfo.iq.entity.ScanAddress;
import com.nfo.iq.entity.URLColor;
import com.nfo.iq.exception.ResourceNotFoundException;
import com.nfo.iq.repository.DomainExceptionRepository;
import com.nfo.iq.repository.DomainRepository;
import com.nfo.iq.repository.OrganizationRepository;
import com.nfo.iq.repository.OrganizationTypeRepository;
import com.nfo.iq.repository.ProgramFileRepository;
import com.nfo.iq.repository.ScanAddressRepository;
import com.nfo.iq.repository.URLColorRepository;
import com.nfo.iq.service.DataImportService;
import com.nfo.iq.utility.MessageConstants;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class DataImportServiceImpl implements DataImportService {

	private final OrganizationRepository organizationRepo;

	private final OrganizationTypeRepository organizationTypeRepo;

	private final ScanAddressRepository scanAddressRepo;

	private final DomainRepository domainRepo;

	private final DomainExceptionRepository domainExceptionsRepo;

	private final URLColorRepository urlColorRepo;

	private final ProgramFileRepository programFileRepo;

	List<Domain> domains = new ArrayList<>();

	List<DomainExceptions> domainExceptions = new ArrayList<>();

	@Override
	public ApiResponse<String> saveUploadFile(MultipartFile file) throws CsvValidationException, IOException {

		ApiResponse<String> apiResponse = new ApiResponse<>();

		if (file.getOriginalFilename().endsWith(".xlsx")) {
			try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
				Sheet noExceptions = workbook.getSheetAt(0);

				Iterator<Row> rowIterator = noExceptions.iterator();

				int rowCount = 0; // Track the number of rows processed

				while (rowIterator.hasNext()) {

					Row row = rowIterator.next();
					// Skip the first two rows
					if (rowCount < 2) {
						rowCount++;
						continue;
					}

					Iterator<Cell> cellIterator = row.iterator();

					Organization org = new Organization();
					Domain dom = new Domain();
					DomainExceptions domExceptions = new DomainExceptions();
					ScanAddress scanAdd = new ScanAddress();

					while (cellIterator.hasNext()) {

						Cell cell = cellIterator.next();

						// Check if cell is empty, if empty, skip the row
						if (cell.getCellType() == CellType.BLANK) {
							break;
						}
						// we will check NoException sheet
						if (row.getCell(4).getStringCellValue().isBlank()
								|| row.getCell(4).getStringCellValue().equals("")
								|| row.getCell(4).getStringCellValue().equalsIgnoreCase("No")) {

							withoutExceptionSheet(row, org, dom, scanAdd);

						}

						// we will check WithException sheet
						else {

							withExceptionSheet(row, org, dom, scanAdd, domExceptions);

						}

						rowCount++; // Increment rowCount for each iteration
					}

				}

				apiResponse.setMessage("Data upload Successfully");
				apiResponse.setResult(true);
				apiResponse.setStatus(HttpStatus.OK.value());
				return apiResponse;
			} catch (IOException ex) {
				apiResponse.setMessage(ex.getMessage());
				apiResponse.setResult(false);
				apiResponse.setStatus(HttpStatus.BAD_REQUEST.value());
				return apiResponse;
			}
		} else if (file.getOriginalFilename().endsWith(".xls")) {
			return uploadDataWithXLS(file);
		} else if (file.getOriginalFilename().endsWith(".csv")) {
			return uploadCSVData(file);
		} else if (file == null || file.isEmpty()) {
			throw new IllegalArgumentException("File is empty");
		} else {
			throw new IllegalArgumentException("Unsupported file format");
		}

	}

	private ApiResponse<String> uploadCSVData(MultipartFile file) throws CsvValidationException, IOException {
		ApiResponse<String> apiResponse = new ApiResponse<>();

		try (InputStream inputStream = file.getInputStream();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				CSVReader csvReader = new CSVReaderBuilder(reader)
						.withCSVParser(new CSVParserBuilder().withSeparator(',').build()).build()) {

			csvReader.readNext(); // Assuming first row contains headers
			csvReader.readNext(); // Assuming second row contains headers

			String[] line;

			while ((line = csvReader.readNext()) != null) {

				Organization org = new Organization();
				Domain dom = new Domain();
				DomainExceptions domExceptions = new DomainExceptions();
				ScanAddress scanAdd = new ScanAddress();

				String domainName = removePrefix(line[2]);
				String domainColor = line[3];

				if (line[4].isBlank() || line[4].equals("") || line[4].equalsIgnoreCase("No")) {

					Organization organization = saveOrganizationForCSV(line, org, scanAdd);

					saveDomain(domainName, domainColor, organization, dom);
				} else {
					withExceptionSheetForCSV(line, org, dom, scanAdd, domExceptions);
				}
			}

		}

		catch (Exception ex) {
			apiResponse.setMessage(ex.getMessage());
			apiResponse.setResult(false);
			apiResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			return apiResponse;
		}

		apiResponse.setMessage("Data upload Successfully");
		apiResponse.setResult(true);
		apiResponse.setStatus(HttpStatus.OK.value());
		return apiResponse;

	}

	private ApiResponse<String> uploadDataWithXLS(MultipartFile file) {
		ApiResponse<String> apiResponse = new ApiResponse<>();

		try (Workbook workbook = new HSSFWorkbook(file.getInputStream())) {
			Sheet sheet = workbook.getSheetAt(0);

			Iterator<Row> rowIterator = sheet.iterator();

			int rowCount = 0; // Track the number of rows processed

			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				// Skip the first two rows
				if (rowCount < 2) {
					rowCount++;
					continue;
				}

				Iterator<Cell> cellIterator = row.cellIterator();

				Organization org = new Organization();
				Domain dom = new Domain();
				DomainExceptions domExceptions = new DomainExceptions();
				ScanAddress scanAdd = new ScanAddress();

				while (cellIterator.hasNext()) {

					Cell cell = cellIterator.next();

					// Check if cell is empty, if empty, skip the row
					if (cell.getCellType() == CellType.BLANK) {
						break;
					}
					// we will check NoException sheet
					if (row.getCell(4).getStringCellValue().isBlank() || row.getCell(4).getStringCellValue().equals("")
							|| row.getCell(4).getStringCellValue().equalsIgnoreCase("No")) {

						withoutExceptionSheet(row, org, dom, scanAdd);

					}

					// we will check WithException sheet
					else {

						withExceptionSheet(row, org, dom, scanAdd, domExceptions);

					}

				}

			}
		} catch (IOException ex) {

			apiResponse.setMessage(ex.getMessage());
			apiResponse.setResult(false);
			apiResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			return apiResponse;
		}
		apiResponse.setMessage("Data upload Successfully");
		apiResponse.setResult(true);
		apiResponse.setStatus(HttpStatus.OK.value());
		return apiResponse;

	}

	private void withoutExceptionSheet(Row row, Organization org, Domain dom, ScanAddress scanAdd) {

		String domainName = removePrefix(row.getCell(2).getStringCellValue());

		String domainColor = row.getCell(3).getStringCellValue();

		Organization organization = saveOrganizationForExcel(row, org, scanAdd);

		saveDomain(domainName, domainColor, organization, dom);

	}

	private void withExceptionSheet(Row row, Organization org, Domain dom, ScanAddress scanAdd,
			DomainExceptions domExceptions) {

		String domainName = removePrefix(row.getCell(2).getStringCellValue());

		String domainColor = row.getCell(3).getStringCellValue();

		Organization organization = saveOrganizationForExcel(row, org, scanAdd);

		Domain saveDomain = saveDomain(domainName, domainColor, organization, dom);

		String domainExpUrl = row.getCell(5).getStringCellValue();

		List<DomainExceptions> listOfDomainExp = domainExceptionsRepo.findByDomainId(saveDomain.getId());

		Optional<DomainExceptions> optionalDomainExp = listOfDomainExp.stream()
				.filter(s -> domainExpUrl.contains(s.getUrl())).findFirst();

		if (optionalDomainExp.isEmpty()) {

			domExceptions.setDomain(saveDomain);

			// set boolean value as per YES/NO from excel
			if ("YES".equals(row.getCell(4).getStringCellValue())) {
				domExceptions.setDomainException(true);
			} else {
				domExceptions.setDomainException(false);
			}

			domExceptions.setUrl(row.getCell(5).getStringCellValue());

			String exColor = row.getCell(6).getStringCellValue();
			Optional<URLColor> isExists = urlColorRepo.findByName(exColor);
			if (isExists.isPresent()) {
				URLColor color = isExists.get();
				domExceptions.setUrlColor(color);
			} else {
				throw new ResourceNotFoundException(exColor + " color not found !!");
			}
			if ("YES".equals(row.getCell(7).getStringCellValue())) {
				domExceptions.setProgramFileException(true);
			} else {

				domExceptions.setProgramFileException(false);
			}
			double programId = row.getCell(8).getNumericCellValue();
			Optional<ProgramFile> isExistsProgramFileeId = programFileRepo.findById((long) programId);
			if (isExistsProgramFileeId.isPresent()) {
				ProgramFile proFile = isExistsProgramFileeId.get();
				domExceptions.setProgramFile(proFile);
				domExceptions.setDomain(dom);

			}
		}
		domainExceptionsRepo.save(domExceptions);
	}

	private Organization saveOrganizationForExcel(Row row, Organization org, ScanAddress scanAdd) {
		String orgValue = row.getCell(1).getStringCellValue();
		double orgTypeId = row.getCell(12).getNumericCellValue();
		Optional<Organization> findByName = organizationRepo.findByName(orgValue);
		if (findByName.isEmpty()) {

			org.setName(orgValue);
			setOrgType(orgTypeId, org);

			Organization savedOrg = organizationRepo.save(org);
			scanAdd.setCity(row.getCell(9).getStringCellValue());
			scanAdd.setState(row.getCell(10).getStringCellValue());
			Double numericCellValue = row.getCell(11).getNumericCellValue();
			int zipCode = numericCellValue.intValue();
//			scanAdd.setZipCode(String.valueOf(row.getCell(11).getNumericCellValue()));
			scanAdd.setZipCode(zipCode);
			scanAdd.setOrganization(savedOrg);
			scanAddressRepo.save(scanAdd);

			return org;
		}

		else {
			return findByName.get();
		}

	}

	private Organization saveOrganizationForCSV(String[] line, Organization org, ScanAddress scanAdd) {
		String orgValue = line[1];

		Long orgTypeId = Long.parseLong(line[12]);
		Optional<Organization> findByName = organizationRepo.findByName(orgValue);
		if (findByName.isEmpty()) {

			org.setName(orgValue);
			setOrgType(orgTypeId, org);

			Organization savedOrg = organizationRepo.save(org);
			scanAdd.setCity(line[9]);
			scanAdd.setState(line[10]);
			scanAdd.setZipCode(Integer.parseInt(line[11]));
			scanAdd.setOrganization(savedOrg);
			scanAddressRepo.save(scanAdd);

			return org;
		}

		else {
			return findByName.get();
		}

	}

	private void withExceptionSheetForCSV(String[] line, Organization org, Domain dom, ScanAddress scanAdd,
			DomainExceptions domExceptions) {

		String domainName = removePrefix(line[2]);

		String domainColor = line[3];

		Organization organization = saveOrganizationForCSV(line, org, scanAdd);

		Domain saveDomain = saveDomain(domainName, domainColor, organization, dom);

		String domainExpUrl = line[5];

		List<DomainExceptions> listOfDomainExp = domainExceptionsRepo.findByDomainId(saveDomain.getId());

		Optional<DomainExceptions> optionalDomainExp = listOfDomainExp.stream()
				.filter(s -> domainExpUrl.contains(s.getUrl())).findFirst();

		if (optionalDomainExp.isEmpty()) {

			domExceptions.setDomain(saveDomain);

			// set boolean value as per YES/NO from excel
			if ("YES".equals(line[4])) {
				domExceptions.setDomainException(true);
			} else {
				domExceptions.setDomainException(false);
			}

			domExceptions.setUrl(line[5]);

			Optional<URLColor> isExists = urlColorRepo.findByName(line[6]);
			if (isExists.isPresent()) {
				URLColor color = isExists.get();
				domExceptions.setUrlColor(color);
				if ("YES".equals(line[7])) {
					domExceptions.setProgramFileException(true);
				} else {

					domExceptions.setProgramFileException(false);
				}
				Long programId = Long.parseLong(line[8]);
				Optional<ProgramFile> isExistsProgramFileeId = programFileRepo.findById(programId);
				if (isExistsProgramFileeId.isPresent()) {
					ProgramFile proFile = isExistsProgramFileeId.get();
					domExceptions.setProgramFile(proFile);
					domExceptions.setDomain(dom);
				}
			}
			domainExceptionsRepo.save(domExceptions);
		}

	}

	private Domain saveDomain(String domainName, String color, Organization organization, Domain domain) {

		Optional<Domain> findByName = domainRepo.findByName(domainName);

		if (findByName.isPresent()) {

			return findByName.get();

		} else {
			domain.setName(domainName);
			domain.setOrganization(organization);
			Optional<URLColor> isExistsName = urlColorRepo.findByName(color);
			URLColor urlColor = null;

			if (isExistsName.isPresent()) {
				urlColor = isExistsName.get();
				domain.setUrlColor(urlColor);
			} else {

				domain.setUrlColor(urlColor);
			}

			return domainRepo.save(domain);
		}

	}

	private void setOrgType(double orgTypeId, Organization org) {

		long orgType = (long) orgTypeId;

		Optional<OrganizationType> isExistsId = organizationTypeRepo.findById(orgType);
		if (isExistsId.isPresent()) {
			OrganizationType organizationType = isExistsId.get();
			org.setOrganizationType(organizationType);
		} else {
			org.setOrganizationType(null);
		}

	}

	public String removePrefix(String str) {
		

		if (!str.isEmpty()) {
			if (str.startsWith(MessageConstants.REMOVE_WWW)) {
				return str.replaceFirst(MessageConstants.REMOVE_WWW, "");
			} else if (str.startsWith(MessageConstants.REMOVE_HTTP)) {
				return str.replaceFirst(MessageConstants.REMOVE_HTTP, "");
			} else if (str.startsWith(MessageConstants.REMOVE_HTTPS)) {
				return str.replaceFirst(MessageConstants.REMOVE_HTTPS, "");
			}
			return str;
		} else {
			return str;
		}
	}

}