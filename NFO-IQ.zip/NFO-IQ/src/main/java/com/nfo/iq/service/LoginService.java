package com.nfo.iq.service;

import com.nfo.iq.dto.request.LoginRequest;
import com.nfo.iq.dto.request.TokenRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.LoginResponse;

public interface LoginService {
	
	
	ApiResponse<LoginResponse> login(LoginRequest loginRequest);
	
	ApiResponse<LoginResponse> generateTokenFromRefreshToken(TokenRequest tokenRequest);
	
	ApiResponse<LoginResponse> logout(String userId);

}
