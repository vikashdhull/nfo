package com.nfo.iq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@PropertySource("file:src/main/resources/messages.properties")
@EnableScheduling
public class NfoIqApplication {

	public static void main(String[] args) {
		SpringApplication.run(NfoIqApplication.class, args);
	}

}
