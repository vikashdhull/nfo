package com.nfo.iq.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nfo.iq.entity.URLColor;

public interface URLColorRepository extends JpaRepository<URLColor, Long> {
	
	Optional<URLColor> findByName(String colorName);

}
