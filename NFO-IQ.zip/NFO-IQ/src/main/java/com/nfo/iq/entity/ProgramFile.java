package com.nfo.iq.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "program_file")
public class ProgramFile extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
