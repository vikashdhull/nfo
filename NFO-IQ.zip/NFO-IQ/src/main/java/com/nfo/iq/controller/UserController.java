package com.nfo.iq.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nfo.iq.dto.request.UpdateUserEmailDto;
import com.nfo.iq.dto.request.UpdateUserMobileDto;
import com.nfo.iq.dto.request.UpdateUserPasswordDto;
import com.nfo.iq.dto.request.UserRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.SubcriptionDetailsResponse;
import com.nfo.iq.dto.response.UserResponse;
import com.nfo.iq.service.UserService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/signup")
	public ResponseEntity<ApiResponse<UserResponse>> createUser(@Valid @RequestBody final UserRequest request) {
		log.info("Enter in createUser Method present in UserController class");

		ApiResponse<UserResponse> response = userService.createUser(request);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PutMapping("/forgot-password/{username}")
	public ResponseEntity<ApiResponse<UserResponse>> forgotPassword(@PathVariable("username") final String username) {
		log.info("Enter in forgotPassword Method present in UserController class");
		ApiResponse<UserResponse> response = userService.forgotPassword(username);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('realm_admin')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<UserResponse>> getUserById(@PathVariable("id") final String userId) {
		log.info("Enter in getUserById Method present in UserController class");
		ApiResponse<UserResponse> response = userService.getUserById(userId);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PutMapping("/update-password")
	public ResponseEntity<ApiResponse<UserResponse>> updatePassword(@Valid @RequestBody final UpdateUserPasswordDto updateUserPasswordDto ,
			Principal principal) {
		log.info("Enter in updatePassword Method present in UserController class");

		ApiResponse<UserResponse> response = userService.updatePassword(principal.getName(), updateUserPasswordDto.getPassword());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PutMapping("/update-mobile")
	public ResponseEntity<ApiResponse<UserResponse>> updateMobile(
			@Valid @RequestBody final UpdateUserMobileDto userMobileDto, Principal principal) {
		log.info("Enter in updateMobile Method present in UserController class");
		String mobileNumber = userMobileDto.getMobileNumber();
		ApiResponse<UserResponse> response = userService.updateMobile(principal.getName(),
				mobileNumber);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PutMapping("/update-email")
	public ResponseEntity<ApiResponse<UserResponse>> updateEmail(
			@Valid @RequestBody final UpdateUserEmailDto userEmailDto, Principal principal) {
		log.info("Enter in updateEmail Method present in UserController class");

		ApiResponse<UserResponse> response = userService.updateEmailById(principal.getName(), userEmailDto.getEmail());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@DeleteMapping("/deactivate")
	public ResponseEntity<ApiResponse<UserResponse>> disableUser(Principal principal){
		log.info("Enter in disableUser Method present in UserController class");

		ApiResponse<UserResponse> response = userService.disableUser(principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@PutMapping("/enable")
	public ResponseEntity<ApiResponse<UserResponse>> enableUser(Principal principal) {
		log.info("Enter in enableUser Method present in UserController class");

		ApiResponse<UserResponse> response = userService.enableUser(principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@GetMapping("/subscription")
	public ResponseEntity<ApiResponse<SubcriptionDetailsResponse>> getUserSubcriptionDetails(Principal principal) {
		log.info("Enter in getUserSubcriptionDetails Method present in UserController class");

		ApiResponse<SubcriptionDetailsResponse> response = userService.getUserSubcriptionDetails(principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}


}
