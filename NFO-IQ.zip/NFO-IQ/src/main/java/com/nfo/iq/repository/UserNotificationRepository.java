package com.nfo.iq.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nfo.iq.entity.UserNotification;

public interface UserNotificationRepository extends JpaRepository<UserNotification, Long> {
	
	List<UserNotification> findByUserId(String UserId);

}
