package com.nfo.iq.exception;

public class DuplicateResourceException extends RuntimeException {
	
	/** long Short Description */
	private static final long serialVersionUID = 1L;

	public DuplicateResourceException() {
		super("Resource not found !!");
	}

	public DuplicateResourceException(String message) {
		super(message);
	}

}
