package com.nfo.iq.service;

import java.util.List;

import com.nfo.iq.dto.request.DomainRequest;
import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.DomainResponse;
import com.nfo.iq.dto.response.PageableResponse;

public interface DomainService {
	
	ApiResponse<DomainResponse> createDomain(DomainRequest domainRequest);

	ApiResponse<DomainResponse> getDomainById(Long domainId);

	ApiResponse<DomainResponse> updateDomain(Long domainId, DomainRequest domainRequest);

	ApiResponse<List<DomainResponse>> getDomains();

	PageableResponse<DomainResponse> getDomainsWithPagination(int pageNumber, int pageSize,
			String sortBy, String sortDir);
	
	ApiResponse<DomainResponse> deleteDomainById(Long domainId);

	ApiResponse<DomainResponse> deleteDomains(RemoveAllRequest request);
}
