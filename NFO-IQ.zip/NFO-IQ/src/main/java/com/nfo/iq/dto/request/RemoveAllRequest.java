package com.nfo.iq.dto.request;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RemoveAllRequest {

	private List<Long> ids;
}
