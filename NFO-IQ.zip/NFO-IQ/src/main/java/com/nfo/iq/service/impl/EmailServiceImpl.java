package com.nfo.iq.service.impl;

import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.nfo.iq.dto.request.VerifyEmailRequest;
import com.nfo.iq.dto.request.VerifyOtpRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.VerifyEmailResponse;
import com.nfo.iq.entity.User;
import com.nfo.iq.entity.VerifyEmailOtp;
import com.nfo.iq.repository.UserRepository;
import com.nfo.iq.repository.VerifyEmailOtpRepository;
import com.nfo.iq.service.EmailService;
import com.nfo.iq.utility.Constants;
import com.nfo.iq.utility.Utility;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailServiceImpl implements EmailService {

	@Value("${spring.mail.username}")
	private String email;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private Utility utility;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private Environment env;

	@Autowired
	private VerifyEmailOtpRepository verifyEmailOtpRepository;

	@Override
	public void sendEmail(String toEmail, String subject, String body) throws UnsupportedEncodingException {
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper;
		try {
			helper = new MimeMessageHelper(message, true);
			helper.setFrom(email, "NFO-IQ");
			helper.setTo(toEmail);
			helper.setSubject(subject);
			helper.setText(body, true);
			mailSender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}

	@Override
	public ApiResponse<VerifyEmailResponse> sendEmailOtp(VerifyEmailRequest verifyEmailRequest) {
		ApiResponse<VerifyEmailResponse> response = new ApiResponse<>();

		try {

			String userEmail = verifyEmailRequest.getEmail();
			
			Optional<User> findUserByEmail = userRepository.findByEmail(userEmail);
			
			if(findUserByEmail.isPresent())
			{
				User user = findUserByEmail.get();
				if(Boolean.TRUE.equals(user.getIsEmailVerified()))
				{
					return utility.errorResponse(response, HttpStatus.CONFLICT, "email.verify.error.message");
				}
			}

			String otp = utility.generateOtp();
			VerifyEmailOtp emailOtp = new VerifyEmailOtp(otp, userEmail);
			Optional<VerifyEmailOtp> findByEmail = verifyEmailOtpRepository.findByEmail(userEmail);
			if (findByEmail.isPresent()) {
				verifyEmailOtpRepository.delete(findByEmail.get());
			}
			verifyEmailOtpRepository.save(emailOtp);

			String bodyString = Constants.EMAIL_OTP_BODY_FIRST + otp + Constants.EMAIL_OTP_BODY_SECOND;

			sendEmail(userEmail, Constants.VERIFY_EMAIL, bodyString);

			response.setMessage("OTP send successfully to " + userEmail);
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());
			return response;
		} catch (Exception ex) {

			response.setMessage(ex.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<VerifyEmailResponse> verifyEmailOtp(VerifyOtpRequest verifyOtpRequest) {
		ApiResponse<VerifyEmailResponse> response = new ApiResponse<>();

		String userEmail = verifyOtpRequest.getEmail();

		Optional<User> findByEmail = userRepository.findByEmail(userEmail);
		Optional<VerifyEmailOtp> findByOtp = verifyEmailOtpRepository.findByOtpAndEmail(verifyOtpRequest.getOtp(),
				userEmail);
		if(findByEmail.isPresent())
		{
			User user = findByEmail.get();
			if(Boolean.TRUE.equals(user.getIsEmailVerified()))
			{
				return utility.errorResponse(response, HttpStatus.CONFLICT, "email.verify.error.message");
			}
		}

		if (findByOtp.isPresent()) {
			VerifyEmailOtp verifyEmailOtp = findByOtp.get();

			if (verifyEmailOtp.getExpiryDate().isBefore(LocalDateTime.now())) {
				verifyEmailOtpRepository.delete(verifyEmailOtp);
				return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "otp.expire.message");

			} else {

				verifyEmailOtpRepository.delete(verifyEmailOtp);
				response.setMessage(env.getProperty("email.verify.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			}
		} else {
			return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "invalid.otp.message");
		}
	}

}
