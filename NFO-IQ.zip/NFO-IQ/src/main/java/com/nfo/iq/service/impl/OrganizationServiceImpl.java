package com.nfo.iq.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException.BadRequest;

import com.nfo.iq.dto.request.OrganizationRequest;
import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.request.ScanAddressRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.OrganizationResponse;
import com.nfo.iq.dto.response.PageableResponse;
import com.nfo.iq.entity.Organization;
import com.nfo.iq.entity.OrganizationType;
import com.nfo.iq.entity.ScanAddress;
import com.nfo.iq.repository.DomainRepository;
import com.nfo.iq.repository.OrganizationRepository;
import com.nfo.iq.repository.OrganizationTypeRepository;
import com.nfo.iq.repository.ScanAddressRepository;
import com.nfo.iq.service.OrganizationService;
import com.nfo.iq.utility.Utility;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrganizationServiceImpl implements OrganizationService {

	@Autowired
	private OrganizationRepository organizationRepository;

	@Autowired
	private OrganizationTypeRepository organizationTypeRepository;

	@Autowired
	private ScanAddressRepository addressRepository;

	@Autowired
	private DomainRepository domainRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	@Override
	public ApiResponse<OrganizationResponse> createOrganization(OrganizationRequest organizationRequest) {
		ApiResponse<OrganizationResponse> response = new ApiResponse<>();

		try {

			Optional<Organization> findByName = organizationRepository.findByName(organizationRequest.getOrgName());

			if (findByName.isEmpty()) {

				Organization dtoToEntity = dtoToEntity(organizationRequest);

				Organization saveOrg = organizationRepository.save(dtoToEntity);

				ScanAddressRequest scanAddress = organizationRequest.getScanAddress();

				if (scanAddress != null) {
					addAddress(saveOrg, scanAddress);
				}

				response.setData(entityToDto(saveOrg));
				response.setResult(true);
				response.setMessage(env.getProperty("organisation.save.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "organisation.save.error.message");
			}

		} catch (Exception e) {
			log.error("Exception in save Organization URL operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	public ApiResponse<OrganizationResponse> getOrganizationById(Long organizationId) {
		ApiResponse<OrganizationResponse> response = new ApiResponse<>();
		try {

			Optional<Organization> organizationDetails = organizationRepository.findById(organizationId);

			if (organizationDetails.isPresent()) {

				Organization organization = organizationDetails.get();

				OrganizationResponse entityToDto = entityToDto(organization);

				response.setData(entityToDto);
				response.setMessage(env.getProperty("organisation.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getOrganizationById Method present in OrganizationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<OrganizationResponse> updateOrganization(Long organizationId,
			OrganizationRequest organizationRequest) {
		ApiResponse<OrganizationResponse> response = new ApiResponse<>();
		try {
			Optional<Organization> organizationDetails = organizationRepository.findById(organizationId);
			Optional<Organization> existByName = organizationRepository.findByName(organizationRequest.getOrgName());

			if (organizationDetails.isPresent()) {
				Organization organizationData = organizationDetails.get();

				if (existByName.isPresent()
						&& !Objects.equals(organizationData.getName(), organizationRequest.getOrgName())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "organisation.name.error.message");

				}
				organizationData.setName(organizationRequest.getOrgName());
				
				Optional<OrganizationType> findByName = organizationTypeRepository.findByName(organizationRequest.getOrgType());
				
				if(findByName.isPresent()) {
					OrganizationType organizationType = findByName.get();
					
					organizationData.setOrganizationType(organizationType);
				}else {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.type.fetch.error.message");
				}
				

				Organization updatedOrg = organizationRepository.save(organizationData);

				ScanAddressRequest scanAddress = organizationRequest.getScanAddress();

				if (scanAddress != null) {
					Optional<ScanAddress> findByOrganizationId = addressRepository
							.findByOrganizationId(updatedOrg.getId());

					if (findByOrganizationId.isPresent()) {
						ScanAddress savedAddress = findByOrganizationId.get();

						savedAddress.setStreetAddress(scanAddress.getStreetAddress());
						savedAddress.setCity(scanAddress.getCity());
						savedAddress.setState(scanAddress.getState());
						savedAddress.setCountry(scanAddress.getCountry());
						savedAddress.setZipCode(scanAddress.getZipCode());
						addressRepository.save(savedAddress);

					} else {
						addAddress(updatedOrg, scanAddress);
					}
				}

				OrganizationResponse updatedOrgDto = entityToDto(updatedOrg);

				response.setData(updatedOrgDto);
				response.setResult(true);
				response.setMessage(env.getProperty("organisation.update.successful.message"));
				response.setStatus(HttpStatus.OK.value());

				return response;
			} else {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in updateOrganization Method present in OrganizationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<OrganizationResponse>> getOrganizations() {
		ApiResponse<List<OrganizationResponse>> response = new ApiResponse<>();

		try {
			List<Organization> organizationsList = organizationRepository.findAll();
			if (!organizationsList.isEmpty()) {
				List<OrganizationResponse> organizationDto = organizationsList.stream().map(this::entityToDto).toList();

				response.setData(organizationDto);
				response.setMessage(env.getProperty("organisation.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getOrganizations Method present in OrganizationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public PageableResponse<OrganizationResponse> getOrganizationsWithPagination(int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Organization> page = organizationRepository.findAll(pageable);

		PageableResponse<OrganizationResponse> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {

				List<OrganizationResponse> orglist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(orglist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND,
						"organisation.fetch.error.message");
			}
		} catch (BadRequest exp) {
			log.error(
					"Exception Occured in getOrganizationsWithPagination Method present in OrganizationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<OrganizationResponse> deleteOrganizationById(Long organizationId) {
		ApiResponse<OrganizationResponse> response = new ApiResponse<>();
		try {

			Optional<Organization> organizationDetails = organizationRepository.findById(organizationId);

			if (organizationDetails.isPresent()) {

				boolean organisationInUse = checkIfOrganisationInUse(organizationId);
				if (organisationInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "organisation.use.error.message");
				}
				organizationRepository.deleteById(organizationId);
				response.setMessage(env.getProperty("organisation.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteOrganizationById Method present in OrganizationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfOrganisationInUse(Long organisationId) {

		return domainRepository.existOrgInDomain(organisationId);
	}

	private OrganizationResponse entityToDto(Organization organization) {

		OrganizationResponse organizationResponse = new OrganizationResponse();
		organizationResponse.setId(organization.getId());
		organizationResponse.setOrgName(organization.getName());

		OrganizationType organizationType = organization.getOrganizationType();

		if (organizationType == null) {
			organizationResponse.setOrgType(null);
		} else {
			organizationResponse.setOrgType(organization.getOrganizationType().getName());
		}

		organizationResponse.setCreatedDate(organization.getCreatedDate());
		organizationResponse.setUpdatedDate(organization.getUpdatedDate());

		Optional<ScanAddress> findByOrganizationId = addressRepository.findByOrganizationId(organization.getId());

		if (findByOrganizationId.isPresent()) {
			ScanAddress scanAddress = findByOrganizationId.get();
			organizationResponse.setStreetAddress(scanAddress.getStreetAddress());
			organizationResponse.setCity(scanAddress.getCity());
			organizationResponse.setState(scanAddress.getState());
			organizationResponse.setCountry(scanAddress.getCountry());
			organizationResponse.setZipCode(scanAddress.getZipCode());
		} else {
			organizationResponse.setStreetAddress(null);
			organizationResponse.setCity(null);
			organizationResponse.setState(null);
			organizationResponse.setCountry(null);
		//	organizationResponse.setZipCode();

		}

		return organizationResponse;
	}

	private Organization dtoToEntity(OrganizationRequest organizationRequest) {

		Organization organization = new Organization();

		organization.setName(organizationRequest.getOrgName());

		Optional<OrganizationType> findOrgType = organizationTypeRepository
				.findByName(organizationRequest.getOrgType());

		if (findOrgType.isEmpty()) {
			organization.setOrganizationType(null);
		} else {
			organization.setOrganizationType(findOrgType.get());
		}

		return organization;
	}

	private void addAddress(Organization org, ScanAddressRequest scanAddress) {
		ScanAddress address = new ScanAddress();

		address.setStreetAddress(scanAddress.getStreetAddress());
		address.setCity(scanAddress.getCity());
		address.setState(scanAddress.getState());
		address.setCountry(scanAddress.getCountry());
		address.setZipCode(scanAddress.getZipCode());
		address.setOrganization(org);

		addressRepository.save(address);
	}

	@Override
	public ApiResponse<OrganizationResponse> removeOrganisations(RemoveAllRequest request) {
		ApiResponse<OrganizationResponse> response = new ApiResponse<>();

		List<Long> ids = request.getIds();
		try {

			List<Organization> orgToRemove = organizationRepository.findByIdIn(ids);

			if (!orgToRemove.isEmpty()) {

				boolean organisationInUse = checkIfOrganisationsInUse(ids);
				if (organisationInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "organisation.use.error.message");
				}

				organizationRepository.deleteAll(orgToRemove);

				response.setResult(true);
				response.setMessage(env.getProperty("organisation.delete.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.fetch.error.message");
			}
		} catch (Exception e) {
			log.error("Exception in remove Organisation operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfOrganisationsInUse(List<Long> organisationIds) {
		return organisationIds.stream().anyMatch(organisationId -> domainRepository.existOrgInDomain(organisationId));
	}

}
