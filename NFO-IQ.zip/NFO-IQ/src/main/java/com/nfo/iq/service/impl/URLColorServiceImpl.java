package com.nfo.iq.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.URLColorResponse;
import com.nfo.iq.entity.URLColor;
import com.nfo.iq.repository.URLColorRepository;
import com.nfo.iq.service.URLColorService;
import com.nfo.iq.utility.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class URLColorServiceImpl implements URLColorService {
	
	@Autowired
	private URLColorRepository urlColorRepository;
	
	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	@Override
	public ApiResponse<List<URLColorResponse>> getURLColors() {
		ApiResponse<List<URLColorResponse>> response = new ApiResponse<>();

		try {
			List<URLColor> urlColors = urlColorRepository.findAll();
			if (!urlColors.isEmpty()) {
				List<URLColorResponse> colorResponseDto = urlColors.stream().map(this::entityToDto).toList();

				response.setData(colorResponseDto);
				response.setMessage(env.getProperty("color.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "color.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getURLColors Method present in URLColorServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}
	
	private URLColorResponse entityToDto(URLColor urlColor) {

		URLColorResponse urlColorResponse = new URLColorResponse();

		urlColorResponse.setId(urlColor.getId());
		urlColorResponse.setName(urlColor.getName());
		

		return urlColorResponse;
	}

}
