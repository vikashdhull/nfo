package com.nfo.iq.repository;

public interface ScanNoticeDomainRepo {

}
