package com.nfo.iq.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TokenResponse {

	@JsonProperty(value = "access_token")
	private String accessToken;

	@JsonProperty(value = "expires_in")
	private int expiresIn;

	@JsonProperty(value = "refresh_expires_in")
	private int refreshExpiresIn;

	@JsonProperty(value = "refresh_token")
	private String refreshToken;

	@JsonProperty(value = "token_type")
	private String tokenType;

	@JsonProperty(value = "not_before_policy")
	private int notBeforePolicy;

	@JsonProperty(value = "session_state")
	private String sessionState;

	private String scope;

}
