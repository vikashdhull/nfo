package com.nfo.iq.service;

import java.util.List;

import com.nfo.iq.dto.request.OrganizationTypeRequest;
import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.OrganizationTypeResponse;
import com.nfo.iq.dto.response.PageableResponse;

public interface OrganizationTypeService {

	ApiResponse<OrganizationTypeResponse> createOrganizationType(OrganizationTypeRequest organizationTypeRequest);

	ApiResponse<OrganizationTypeResponse> getOrganizationTypeById(Long organizationTypeId);

	ApiResponse<OrganizationTypeResponse> updateOrganizationType(Long organizationTypeId, OrganizationTypeRequest organizationTypeRequest);

	ApiResponse<List<OrganizationTypeResponse>> getOrganizationTypes();

	PageableResponse<OrganizationTypeResponse> getOrganizationTypesWithPagination(int pageNumber, int pageSize,
			String sortBy, String sortDir);
	
	
	ApiResponse<OrganizationTypeResponse> deleteOrganizationTypeById(Long organizationId);

	ApiResponse<OrganizationTypeResponse> deleteOrganisationTypes(RemoveAllRequest request);

}
