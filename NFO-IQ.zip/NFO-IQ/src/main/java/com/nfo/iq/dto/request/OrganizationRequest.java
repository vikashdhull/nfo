package com.nfo.iq.dto.request;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OrganizationRequest {
	
	private String orgName;
	
	private String orgType;
	
	private ScanAddressRequest scanAddress;

}
