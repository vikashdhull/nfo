package com.nfo.iq.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoginResponse {
	
	@JsonProperty(value = "access_token")
	private String accessToken;

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	@JsonProperty(value = "expires_in")
	private int expiresIn;

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	@JsonProperty(value = "refresh_expires_in")
	private int refreshExpiresIn;

	@JsonProperty(value = "refresh_token")
	private String refreshToken;

	@JsonProperty(value = "token_type")
	private String tokenType;
	
//	private String message;
//	
//	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
//	private int status;

}
