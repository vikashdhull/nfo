package com.nfo.iq.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRequest {
	
	@Email(message = "Invalid User Email !!")  
	@NotBlank(message = "Email is required !!")
	private String email;
	
	private Boolean isEmailVerified;
	
	private String password;
	
	@Pattern(regexp="(^$|\\d{10})", message = "Invalid Phone number")
	private String mobileNumber;
	
	private Boolean paymentStatus;

}
