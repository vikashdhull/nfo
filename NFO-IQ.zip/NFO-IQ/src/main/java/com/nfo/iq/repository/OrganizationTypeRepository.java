package com.nfo.iq.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nfo.iq.entity.OrganizationType;

public interface OrganizationTypeRepository extends JpaRepository<OrganizationType, Long> {

	Optional<OrganizationType> findByName(String name);
	
	List<OrganizationType> findByIdIn(List<Long> ids);
}
