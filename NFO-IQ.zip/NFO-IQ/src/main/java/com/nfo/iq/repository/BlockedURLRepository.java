package com.nfo.iq.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nfo.iq.entity.BlockedURL;

public interface BlockedURLRepository extends JpaRepository<BlockedURL, Long>{
	
	final String BLOCKED_URL = "SELECT * FROM blocked_url bu WHERE bu.user_id = :id and bu.webpage_url LIKE '%' || :webPageUrl || '%'";

	
	Optional<BlockedURL> findByUserIdAndWebpageURL(String id, String webPageUrl);
	
	Optional<BlockedURL> findByIdAndUserId(Long id, String webPageUrl);
	
	
	@Query(value = BLOCKED_URL, nativeQuery = true)
	Optional<BlockedURL> findBlockedUrl(String id, String webPageUrl);

}
