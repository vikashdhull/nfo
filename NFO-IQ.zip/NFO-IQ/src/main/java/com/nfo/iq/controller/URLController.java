package com.nfo.iq.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nfo.iq.dto.request.ScanDataRequest;
import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.request.URLRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.PageableResponse;
import com.nfo.iq.dto.response.URLDataResponse;
import com.nfo.iq.dto.response.URLResponse;
import com.nfo.iq.dto.response.WebpageScanHistoryResponse;
import com.nfo.iq.service.URLService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/urls")
@Slf4j
public class URLController {
	
	@Autowired
	private URLService urlService;
	
	@PostMapping("/verify")
	public ResponseEntity<ApiResponse<URLDataResponse>> verifyScanedURL(@Valid @RequestBody final ScanDataRequest request, Principal principal) {
		log.info("Enter in urlVerify Method present in URLController class");

		ApiResponse<URLDataResponse> response = urlService.verifyScanedURL(request, principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@PostMapping("/trusted")
	public ResponseEntity<ApiResponse<URLResponse>> saveTrustedUrl(@Valid @RequestBody final URLRequest request, Principal principal) {
		log.info("Enter in saveTrustedUrl Method present in URLController class");

		ApiResponse<URLResponse> response = urlService.saveTrustedUrl(request, principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@DeleteMapping("/trusted")
	public ResponseEntity<ApiResponse<URLDataResponse>> removeTrustedUrl(@Valid @RequestBody final RemoveAllRequest request, Principal principal) {
		log.info("Enter in removeTrustedUrl Method present in URLController class");

		ApiResponse<URLDataResponse> response = urlService.removeTrustedUrls(request, principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@PostMapping("/blocked")
	public ResponseEntity<ApiResponse<URLResponse>> blockedUrl(@Valid @RequestBody final URLRequest request, Principal principal) {
		log.info("Enter in blockedUrl Method present in URLController class");

		ApiResponse<URLResponse> response = urlService.blockedUrl(request, principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@PostMapping("/unblocked")
	public ResponseEntity<ApiResponse<URLResponse>> unblockedUrl(@Valid @RequestBody final URLRequest request, Principal principal) {
		log.info("Enter in unblockedUrl Method present in URLController class");

		ApiResponse<URLResponse> response = urlService.unblockedUrl(request, principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@PostMapping("/history")
	public ResponseEntity<ApiResponse<WebpageScanHistoryResponse>> saveUrlHistory(@Valid @RequestBody final URLRequest request, Principal principal) {
		log.info("Enter in saveUrlHistory Method present in URLController class");

		ApiResponse<WebpageScanHistoryResponse> response = urlService.saveUrlHistory(request, principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@GetMapping("/trusted")
	public ResponseEntity<PageableResponse<URLResponse>> getAllTrustedURL(
			Principal principal,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "webpageURL", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllUsers Method present in UserController class");

		PageableResponse<URLResponse> response = urlService.getAllTrustedURL(principal.getName(), pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}
	
	@GetMapping("/history")
	public ResponseEntity<PageableResponse<WebpageScanHistoryResponse>> getAllScannedURL(
			Principal principal,
			@RequestParam(value = "distinct", defaultValue = "false", required = false) boolean distinct,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "webpageURL", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllUsers Method present in UserController class");

		PageableResponse<WebpageScanHistoryResponse> response = urlService.getAllScannedURL(principal.getName(), distinct, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

}
