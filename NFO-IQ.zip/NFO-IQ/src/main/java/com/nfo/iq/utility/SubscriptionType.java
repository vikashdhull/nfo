package com.nfo.iq.utility;

public enum SubscriptionType {
	
	FREE, PAID, EXPIRED

}
