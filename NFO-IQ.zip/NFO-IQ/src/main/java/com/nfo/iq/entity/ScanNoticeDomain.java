package com.nfo.iq.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "scan_notice_domain")
@Getter
@Setter
public class ScanNoticeDomain extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "scan_notice_id", referencedColumnName = "id")
	private ScanNotice scanNotice;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "domain_id", referencedColumnName = "id")
	private Domain domain;
	
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH, optional = true)
	@JoinColumn(name = "domain_exceptions_id", referencedColumnName = "id")
	private DomainExceptions domainExceptions;
	
	@Column(name = "is_domain_exception")
	private Boolean isDomainException;

}
