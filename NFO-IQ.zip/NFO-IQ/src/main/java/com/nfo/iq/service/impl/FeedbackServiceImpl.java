package com.nfo.iq.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.nfo.iq.dto.request.FeedbackRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.FeedbackResponse;
import com.nfo.iq.entity.Feedback;
import com.nfo.iq.entity.User;
import com.nfo.iq.repository.FeedbackRepository;
import com.nfo.iq.repository.UserRepository;
import com.nfo.iq.service.FeedbackService;
import com.nfo.iq.utility.Constants;
import com.nfo.iq.utility.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FeedbackServiceImpl implements FeedbackService {

	@Autowired
	FeedbackRepository feedbackRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	@Override
	public ApiResponse<FeedbackResponse> saveFeedback(FeedbackRequest feedbackRequest, String userId) {

		ApiResponse<FeedbackResponse> response = new ApiResponse<>();

		try {
			Optional<User> optionalUser = userRepository.findById(userId);

			if (optionalUser.isEmpty()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}

			User user = optionalUser.get();
			
			Feedback feedback = new Feedback();
			feedback.setComment(feedbackRequest.getComment());
			feedback.setPoint(feedbackRequest.getPoint());
			feedback.setUser(user);

			feedbackRepository.save(feedback);
			
			utility.addNotification(user, Constants.NOTIFICATION_FEEDBACK);

			FeedbackResponse feedbackResponse = new FeedbackResponse();

			feedbackResponse.setId(feedback.getId());
			feedbackResponse.setComment(feedback.getComment());
			feedbackResponse.setPoint(feedback.getPoint());
			feedbackResponse.setUser(feedback.getUser().getEmail());
			feedbackResponse.setCreatedDate(feedback.getCreatedDate());

			response.setData(feedbackResponse);
			response.setResult(true);
			response.setMessage(env.getProperty("feedback.post.success.message"));
			response.setStatus(HttpStatus.OK.value());
			return response;
		} catch (Exception e) {
			log.error("Exception in save Feedback URL operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

}
