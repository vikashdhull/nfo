package com.nfo.iq.service;

import java.io.UnsupportedEncodingException;

import com.nfo.iq.dto.request.VerifyEmailRequest;
import com.nfo.iq.dto.request.VerifyOtpRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.VerifyEmailResponse;

public interface EmailService {
	
	void sendEmail(String toEmail, String subject, String body) throws UnsupportedEncodingException;
	
	ApiResponse<VerifyEmailResponse> sendEmailOtp(VerifyEmailRequest verifyEmailRequest);
	
	ApiResponse<VerifyEmailResponse> verifyEmailOtp(VerifyOtpRequest verifyOtpRequest);
	
}
