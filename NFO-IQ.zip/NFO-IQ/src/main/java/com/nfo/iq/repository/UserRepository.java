package com.nfo.iq.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nfo.iq.entity.User;
import com.nfo.iq.utility.SubscriptionType;

public interface UserRepository extends JpaRepository<User, String> {

	Optional<User> findByUsername(String username);

	Optional<User> findByEmail(String email); 

	Optional<User> findByMobileNumber(String mobile);
	
	List<User> findBySubscriptionTypeAndIsEnable(SubscriptionType subscriptionType, Boolean isEnable);

}
