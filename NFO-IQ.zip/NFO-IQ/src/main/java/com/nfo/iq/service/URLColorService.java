package com.nfo.iq.service;

import java.util.List;

import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.URLColorResponse;

public interface URLColorService {
	
	ApiResponse<List<URLColorResponse>> getURLColors();

}
