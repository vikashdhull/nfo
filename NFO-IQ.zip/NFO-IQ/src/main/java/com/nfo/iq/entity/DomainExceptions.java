package com.nfo.iq.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "domain_exception")
@Getter
@Setter
public class DomainExceptions extends BaseEntity {

    /**
    * 
     */
    private static final long serialVersionUID = 1L;
    
    @Column(name = "url", length = 2300)
    private String url;
    
    @Column(name = "domain_exception")
    private boolean domainException;
    
    @Column(name = "program_file_exception")
    private boolean programFileException;
    
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
    @JoinColumn(name = "program_file_id", referencedColumnName = "id")
    private ProgramFile programFile;
    
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
    @JoinColumn(name = "domain_id", referencedColumnName = "id")
    private Domain domain;
    
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "url_color_id", referencedColumnName = "id")
	private URLColor urlColor;

}

