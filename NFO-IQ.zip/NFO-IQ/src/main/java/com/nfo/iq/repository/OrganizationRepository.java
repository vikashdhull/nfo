package com.nfo.iq.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nfo.iq.entity.Organization;

public interface OrganizationRepository extends JpaRepository<Organization, Long>{
	
	final String EXIST_ORGANISATION_TYPE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM organization o WHERE o.organization_type_id=:organisationTypeId";
	
	@Query(value = EXIST_ORGANISATION_TYPE, nativeQuery = true)
	boolean existOrgTypeInOrg(Long organisationTypeId);

	Optional<Organization> findByName(String name);
	
	List<Organization> findByIdIn(List<Long> ids);

}
