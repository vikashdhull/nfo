package com.nfo.iq.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException.BadRequest;

import com.nfo.iq.dto.request.OrganizationTypeRequest;
import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.OrganizationTypeResponse;
import com.nfo.iq.dto.response.PageableResponse;
import com.nfo.iq.entity.OrganizationType;
import com.nfo.iq.repository.OrganizationRepository;
import com.nfo.iq.repository.OrganizationTypeRepository;
import com.nfo.iq.service.OrganizationTypeService;
import com.nfo.iq.utility.Utility;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrganizationTypeServiceImpl implements OrganizationTypeService {

	@Autowired
	private OrganizationRepository organizationRepository;

	@Autowired
	private OrganizationTypeRepository organizationTypeRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	@Override
	public ApiResponse<OrganizationTypeResponse> createOrganizationType(
			OrganizationTypeRequest organizationTypeRequest) {
		ApiResponse<OrganizationTypeResponse> response = new ApiResponse<>();

		try {

			Optional<OrganizationType> findByName = organizationTypeRepository.findByName(organizationTypeRequest.getName());

			if (findByName.isEmpty()) {

				OrganizationType dtoToEntity = dtoToEntity(organizationTypeRequest);

				OrganizationType saveOrg = organizationTypeRepository.save(dtoToEntity);

				response.setData(entityToDto(saveOrg));
				response.setResult(true);
				response.setMessage(env.getProperty("organisation.type.save.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "organisation.type.save.error.message");
			}

		} catch (Exception e) {
			log.error("Exception in save Organization Type URL operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	public ApiResponse<OrganizationTypeResponse> getOrganizationTypeById(Long organizationTypeId) {
		ApiResponse<OrganizationTypeResponse> response = new ApiResponse<>();
		try {

			Optional<OrganizationType> organizationTypeDetails = organizationTypeRepository.findById(organizationTypeId);

			if (organizationTypeDetails.isPresent()) {

				OrganizationType organizationType = organizationTypeDetails.get();

				OrganizationTypeResponse entityToDto = entityToDto(organizationType);

				response.setData(entityToDto);
				response.setMessage(env.getProperty("organisation.type.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.type.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getOrganizationTypeById Method present in OrganizationTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<OrganizationTypeResponse> updateOrganizationType(Long organizationTypeId,
			OrganizationTypeRequest organizationTypeRequest) {
		ApiResponse<OrganizationTypeResponse> response = new ApiResponse<>();
		try {
			Optional<OrganizationType> organizationTypeDetails = organizationTypeRepository.findById(organizationTypeId);
			Optional<OrganizationType> existByName = organizationTypeRepository.findByName(organizationTypeRequest.getName());

			if (organizationTypeDetails.isPresent()) {
				OrganizationType organizationTypeData = organizationTypeDetails.get();

				if (existByName.isPresent()
						&& !Objects.equals(organizationTypeData.getName(), organizationTypeRequest.getName())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "organisation.type.name.error.message");

				}
				organizationTypeData.setName(organizationTypeRequest.getName());

				OrganizationType updatedOrgType = organizationTypeRepository.save(organizationTypeData);

				

				OrganizationTypeResponse updatedOrgTypeDto = entityToDto(updatedOrgType);

				response.setData(updatedOrgTypeDto);
				response.setResult(true);
				response.setMessage(env.getProperty("organisation.type.update.successful.message"));
				response.setStatus(HttpStatus.OK.value());

				return response;
			} else {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.type.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in updateOrganizationType Method present in OrganizationTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<OrganizationTypeResponse>> getOrganizationTypes() {
		ApiResponse<List<OrganizationTypeResponse>> response = new ApiResponse<>();

		try {
			List<OrganizationType> organizationTypesList = organizationTypeRepository.findAll();
			if (!organizationTypesList.isEmpty()) {
				List<OrganizationTypeResponse> organizationTypeDto = organizationTypesList.stream().map(this::entityToDto).toList();

				response.setData(organizationTypeDto);
				response.setMessage(env.getProperty("organisation.type.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.type.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getOrganizationTypes Method present in OrganizationTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public PageableResponse<OrganizationTypeResponse> getOrganizationTypesWithPagination(int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<OrganizationType> page = organizationTypeRepository.findAll(pageable);

		PageableResponse<OrganizationTypeResponse> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {

				List<OrganizationTypeResponse> orglist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(orglist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND,
						"organisation.type.fetch.error.message");
			}
		} catch (BadRequest exp) {
			log.error(
					"Exception Occured in getOrganizationTypesWithPagination Method present in OrganizationTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<OrganizationTypeResponse> deleteOrganizationTypeById(Long organizationTypeId) {
		ApiResponse<OrganizationTypeResponse> response = new ApiResponse<>();
		try {

			Optional<OrganizationType> organizationTypeDetails = organizationTypeRepository.findById(organizationTypeId);

			if (organizationTypeDetails.isPresent()) {

				boolean organisationTypeInUse = checkIfOrganisationTypeInUse(organizationTypeId);
				if (organisationTypeInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "organisation.type.use.error.message");
				}
				organizationTypeRepository.deleteById(organizationTypeId);
				response.setMessage(env.getProperty("organisation.type.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.type.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteOrganizationTypeById Method present in OrganizationTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<OrganizationTypeResponse> deleteOrganisationTypes(RemoveAllRequest request) {
		ApiResponse<OrganizationTypeResponse> response = new ApiResponse<>();

		List<Long> ids = request.getIds();
		try {

			List<OrganizationType> orgTypeToRemove = organizationTypeRepository.findByIdIn(ids);

			if (!orgTypeToRemove.isEmpty()) {

				boolean organisationTypeInUse = checkIfOrganisationTypesInUse(ids);
				if (organisationTypeInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "organisation.type.use.error.message");
				}

				organizationTypeRepository.deleteAll(orgTypeToRemove);

				response.setResult(true);
				response.setMessage(env.getProperty("organisation.type.delete.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.type.fetch.error.message");
			}
		} catch (Exception e) {
			log.error("Exception in delete multiple Organisation operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}
	
	private boolean checkIfOrganisationTypesInUse(List<Long> organisationTypeIds) {
		return organisationTypeIds.stream().anyMatch(organisationTypeId -> organizationRepository.existOrgTypeInOrg(organisationTypeId));
	}
	
	private boolean checkIfOrganisationTypeInUse(Long organisationTypeId) {
		return organizationRepository.existOrgTypeInOrg(organisationTypeId);
	}

	private OrganizationTypeResponse entityToDto(OrganizationType organizationType) {

		OrganizationTypeResponse organizationTypeResponse= new OrganizationTypeResponse();
		
		organizationTypeResponse.setId(organizationType.getId());
		organizationTypeResponse.setName(organizationType.getName());
		
		return organizationTypeResponse;
	}

	private OrganizationType dtoToEntity(OrganizationTypeRequest organizationTypeRequest) {

		OrganizationType organizationType = new OrganizationType();

		organizationType.setName(organizationTypeRequest.getName());

		return organizationType;
	}


}
