package com.nfo.iq.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.service.DataImportService;
import com.opencsv.exceptions.CsvValidationException;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/data")
@Slf4j
@CrossOrigin(origins = "http://localhost:3000")
public class DataImportController {

	@Autowired
	private DataImportService dataImportService;

	@PostMapping("/import")
	public ResponseEntity<ApiResponse<String>> saveUploadFile(@RequestParam("file") MultipartFile file) throws CsvValidationException, IOException {
		log.info("Enter in saveUploadFile Method present in DataImportController class");

		ApiResponse<String> response = dataImportService.saveUploadFile(file);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
