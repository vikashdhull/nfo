package com.nfo.iq.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class URLRequest {

	private String url;
}
