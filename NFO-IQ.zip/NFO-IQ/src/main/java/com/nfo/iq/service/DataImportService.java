package com.nfo.iq.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.nfo.iq.dto.response.ApiResponse;
import com.opencsv.exceptions.CsvValidationException;

public interface DataImportService {
	
	ApiResponse<String> saveUploadFile(MultipartFile file) throws CsvValidationException, IOException;

}
