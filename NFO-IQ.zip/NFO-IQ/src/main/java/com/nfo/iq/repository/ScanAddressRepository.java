package com.nfo.iq.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nfo.iq.entity.ScanAddress;

public interface ScanAddressRepository extends JpaRepository<ScanAddress, Long> {
	
	Optional<ScanAddress> findByOrganizationId(Long orgId);

}
