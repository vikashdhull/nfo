package com.nfo.iq.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException.BadRequest;

import com.nfo.iq.dto.request.DomainRequest;
import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.DomainResponse;
import com.nfo.iq.dto.response.PageableResponse;
import com.nfo.iq.entity.Domain;
import com.nfo.iq.entity.Organization;
import com.nfo.iq.entity.URLColor;
import com.nfo.iq.exception.ResourceNotFoundException;
import com.nfo.iq.repository.DomainExceptionRepository;
import com.nfo.iq.repository.DomainRepository;
import com.nfo.iq.repository.OrganizationRepository;
import com.nfo.iq.repository.URLColorRepository;
import com.nfo.iq.service.DomainService;
import com.nfo.iq.utility.Utility;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DomainServiceImpl implements DomainService {

	@Autowired
	private DomainRepository domainRepository;

	@Autowired
	private DomainExceptionRepository domainExceptionRepository;

	@Autowired
	private URLColorRepository urlColorRepository;

	@Autowired
	private OrganizationRepository organizationRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	@Override
	public ApiResponse<DomainResponse> createDomain(DomainRequest domainRequest) {
		ApiResponse<DomainResponse> response = new ApiResponse<>();

		try {

			Optional<Domain> findByName = domainRepository.findByName(domainRequest.getName());

			if (findByName.isEmpty()) {

				Domain domain = dtoToEntity(domainRequest);
				
				Optional<URLColor> findUrlColor = urlColorRepository.findByName(domainRequest.getName());
				if (findUrlColor.isPresent()) {
					
					domain.setUrlColor(findUrlColor.get());

				}else {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "color.fetch.error.message");
				}
				
				Domain saveDomain = domainRepository.save(domain);

				response.setData(entityToDto(saveDomain));
				response.setResult(true);
				response.setMessage(env.getProperty("domain.save.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "domain.save.error.message");
			}

		} catch (Exception e) {
			log.error("Exception in save Domain Type URL operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	public ApiResponse<DomainResponse> getDomainById(Long domainId) {
		ApiResponse<DomainResponse> response = new ApiResponse<>();
		try {

			Optional<Domain> domainDetails = domainRepository.findById(domainId);

			if (domainDetails.isPresent()) {

				Domain domain = domainDetails.get();

				DomainResponse entityToDto = entityToDto(domain);

				response.setData(entityToDto);
				response.setMessage(env.getProperty("domain.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "domain.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getDomainById Method present in DomainServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<DomainResponse> updateDomain(Long domainId, DomainRequest domainRequest) {
		ApiResponse<DomainResponse> response = new ApiResponse<>();
		try {
			Optional<Domain> domainDetails = domainRepository.findById(domainId);
			Optional<Domain> existByName = domainRepository.findByName(domainRequest.getName());

			if (domainDetails.isPresent()) {
				Domain domainData = domainDetails.get();

				if (existByName.isPresent() && !Objects.equals(domainData.getName(), domainRequest.getName())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "domain.name.error.message");

				}
				domainData.setName(domainRequest.getName());

				Optional<Organization> findByName = organizationRepository.findByName(domainRequest.getOrgName());

				if (findByName.isPresent()) {

					domainData.setOrganization(findByName.get());
				} else {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organisation.fetch.error.message");
				}
				
				Optional<URLColor> findUrlColor = urlColorRepository.findByName(domainRequest.getColor());
				if (findUrlColor.isPresent()) {
					
					domainData.setUrlColor(findUrlColor.get());

				}else {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "color.fetch.error.message");
				}

				Domain updatedDomain = domainRepository.save(domainData);

				DomainResponse updatedDomainDto = entityToDto(updatedDomain);

				response.setData(updatedDomainDto);
				response.setResult(true);
				response.setMessage(env.getProperty("domain.update.successful.message"));
				response.setStatus(HttpStatus.OK.value());

				return response;
			} else {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "domain.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in updateDomain Method present in DomainServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<DomainResponse>> getDomains() {
		ApiResponse<List<DomainResponse>> response = new ApiResponse<>();

		try {
			List<Domain> domainList = domainRepository.findAll();
			if (!domainList.isEmpty()) {
				List<DomainResponse> domainDto = domainList.stream().map(this::entityToDto).toList();

				response.setData(domainDto);
				response.setMessage(env.getProperty("domain.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "domain.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getDomains Method present in DomainServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public PageableResponse<DomainResponse> getDomainsWithPagination(int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Domain> page = domainRepository.findAll(pageable);

		PageableResponse<DomainResponse> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {

				List<DomainResponse> domainList = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(domainList);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, "domain.fetch.error.message");
			}
		} catch (BadRequest exp) {
			log.error("Exception Occured in getDomainsWithPagination Method present in DomainServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<DomainResponse> deleteDomainById(Long domainId) {
		ApiResponse<DomainResponse> response = new ApiResponse<>();
		try {

			Optional<Domain> domainDetails = domainRepository.findById(domainId);

			if (domainDetails.isPresent()) {

				boolean domainInUse = checkIfDomainInUse(domainId);
				if (domainInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "domain.use.error.message");
				}

				domainRepository.deleteById(domainId);
				response.setMessage(env.getProperty("domain.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "domain.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteDomainById Method present in DomainServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<DomainResponse> deleteDomains(RemoveAllRequest request) {
		ApiResponse<DomainResponse> response = new ApiResponse<>();

		List<Long> ids = request.getIds();
		try {

			List<Domain> domainToRemove = domainRepository.findByIdIn(ids);

			if (!domainToRemove.isEmpty()) {

				boolean domainInUse = checkIfDomainsInUse(ids);
				if (domainInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "domain.use.error.message");
				}

				domainRepository.deleteAll(domainToRemove);

				response.setResult(true);
				response.setMessage(env.getProperty("domain.delete.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "domain.fetch.error.message");
			}
		} catch (Exception e) {
			log.error("Exception in delete multiple Domain operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfDomainsInUse(List<Long> domainIds) {
		return domainIds.stream()
				.anyMatch(domainId -> domainExceptionRepository.existDomainInDomainException(domainId));
	}

	private boolean checkIfDomainInUse(Long domainId) {
		return domainExceptionRepository.existDomainInDomainException(domainId);
	}

	private DomainResponse entityToDto(Domain domain) {

		DomainResponse domainResponse = new DomainResponse();

		domainResponse.setId(domain.getId());
		domainResponse.setName(domain.getName());
		domainResponse.setOrgName(domain.getOrganization().getName());
		
		String domainColor = domain.getUrlColor().getName();

		if (domainColor != null) {
			domainResponse.setDomainColor(domain.getUrlColor().getName());
		} else {
			domainResponse.setDomainColor(null);
		}
		
		domainResponse.setCreatedDate(domain.getCreatedDate());
		domainResponse.setUpdatedDate(domain.getUpdatedDate());

		return domainResponse;
	}

	private Domain dtoToEntity(DomainRequest domainRequest) {

		Domain domain = new Domain();

		domain.setName(domainRequest.getName());

		Optional<Organization> findByName = organizationRepository.findByName(domainRequest.getName());

		if (findByName.isPresent()) {

			domain.setOrganization(findByName.get());
		} else {
			throw new ResourceNotFoundException(env.getProperty("domain.fetch.error.message"));
		}

		return domain;
	}

}
