package com.nfo.iq.service;

import java.util.List;

import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.UserNotificationResponse;

public interface UserNotificationService {
	
	ApiResponse<UserNotificationResponse> readNotification(Long notificationId);
	
	ApiResponse<List<UserNotificationResponse>> getAllNotificationByUser(String userId);
	
	ApiResponse<UserNotificationResponse> removeNotification(Long id);

}
