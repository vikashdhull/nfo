package com.nfo.iq.utility;

public class Constants {

	private Constants() {
	}

	public static final String NFO_REALM_NAME = "NfoSmart-Realm";

	public static final String ACCOUNT_DEACTIVATION = "Account Deactivation Confirmation";

	public static final String VERIFY_EMAIL = "Email verification OTP";

	public static final String DISABLE_USER_BODY_STRING = "<p>Dear Member,</p>"
			+ "<p>Your account deactivation request has been successfully processed. As per your request, your account has been disabled, and all associated features and services have been deactivated.</p>"
			+ "<p>Should you have any questions or require any further assistance, please feel free to contact our support team at <a href="
			+ "mailto:support@nfosmart.com" + ">support@nfosmart.com</a>."
			+ "<p>Thank you for being a valued member of our community.</p>" + "<p><b>Best regards,</b></p>"
			+ "<p><u>NFO-IQ</u></p>";

	public static final String EMAIL_OTP_BODY_FIRST = "<p>Dear Member,</p>"
			+ "<p>Thank you for registering with our platform. To complete your registration and verify your email address, please enter the OTP code below:</p>"
			+ "<p>OTP Code: " + "<b>";

	public static final String EMAIL_OTP_BODY_SECOND = "</b></p>" + "<p></p>"
			+"<p>If you did not register on our platform, please ignore this email.</p>"
			+"If you have any questions or need further assistance, please feel free to contact our support team at <a href="
			+"mailto:support@nfosmart.com"+ ">support@nfosmart.com</a>."
			+"<p></p>" + "<p><b>Best regards,</b></p>" + "<p><u>NFO-IQ</u></p>";

	public static final String NFO_CLIENT_ID = "";

	public static final String NFO_CLIENT_SECRET = "";

	public static final String UPDATE_PASSWORD = "UPDATE_PASSWORD";

	public static final String UPDATE_PROFILE = "UPDATE_PROFILE";

	public static final String PASSWORD = "password";
	
	public static final String REFRESH_TOKEN = "refresh_token";

	public static final String CLIENT_ID = "client_id";

	public static final String CLIENT_SECRET = "client_secret";

	public static final String GRANT_TYPE = "grant_type";

	public static final String USERNAME = "username";

	public static final String MOBILE = "mobile";

	public static final String SUBSCRIPTION_TYPE = "subscriptionType";

	public static final String SUBSCRIPTION_START_DATE = "subscriptionStartDate";

	public static final String REALM = "realms/";

	public static final String REALMS = "realms";

	public static final String PROTOCOL_TOKEN = "/protocol/openid-connect/token";

	public static final Long NOTIFICATION_WELCOME = 1L;

	public static final Long NOTIFICATION_FEEDBACK = 2L;

	public static final String LINK = "link";

	public static final String OTHER = "other";

	public static final String FTP = "ftp";

	public static final String VCARD = "vcard";

	public static final String TEXT = "text";

	public static final String EMAIL = "email";

	public static final String PAYMENT_APP = "Payment App";
}
