package com.nfo.iq.service;

import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.request.ScanDataRequest;
import com.nfo.iq.dto.request.URLRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.PageableResponse;
import com.nfo.iq.dto.response.URLResponse;
import com.nfo.iq.dto.response.WebpageScanHistoryResponse;
import com.nfo.iq.dto.response.URLDataResponse;

public interface URLService {
	
	ApiResponse<URLDataResponse> verifyScanedURL(ScanDataRequest scanDataRequest, String userId);
	
	ApiResponse<URLResponse> saveTrustedUrl(URLRequest urlRequest, String userId);
	
	ApiResponse<URLDataResponse> removeTrustedUrls(RemoveAllRequest request, String userId);
	
	ApiResponse<URLResponse> blockedUrl(URLRequest urlRequest, String userId);
	
	ApiResponse<WebpageScanHistoryResponse> saveUrlHistory(URLRequest urlRequest, String userId);
	
	ApiResponse<URLResponse> unblockedUrl(URLRequest urlRequest, String userId);
	
	PageableResponse<URLResponse> getAllTrustedURL(String userId, int pageNumber, int pageSize, String sortBy, String sortDir);
	
	PageableResponse<WebpageScanHistoryResponse> getAllScannedURL(String userId, boolean distinct, int pageNumber, int pageSize, String sortBy, String sortDir);

}
