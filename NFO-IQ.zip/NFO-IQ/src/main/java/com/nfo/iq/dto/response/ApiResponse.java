package com.nfo.iq.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {

	private T data;
	private boolean result;
	private String message;
	private int status;

	public ApiResponse(int status, boolean result, String message) {
		this.status = status;
		this.result = result;
		this.message = message;
	}

	public ApiResponse(T data, boolean result, String message, int status) {
		this.data = data;
		this.result = result;
		this.message = message;
		this.status = status;
	}

}
