package com.nfo.iq.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.UserRepresentation;
import org.keycloak.representations.idm.UserSessionRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.nfo.iq.dto.request.LoginRequest;
import com.nfo.iq.dto.request.TokenRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.LoginResponse;
import com.nfo.iq.entity.User;
import com.nfo.iq.exception.BadApiRequestException;
import com.nfo.iq.repository.UserRepository;
import com.nfo.iq.service.LoginService;
import com.nfo.iq.utility.Constants;
import com.nfo.iq.utility.Utility;

@Service
public class LoginServiceImpl implements LoginService {

	@Value("${keycloak.client.id}")
	private String clientId;

	@Value("${keycloak.client.secret}")
	private String clientSecret;

	@Value("${keycloak.realm}")
	private String realm;

	@Value("${keycloak.auth-server-url}")
	private String serverUrl;

	@Autowired
	public AuthenticationManager authenticationManager;

	@Autowired
	Keycloak keycloak;

	@Autowired
	private WebClient webClient;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private Utility utility;

	@Override
	public ApiResponse<LoginResponse> login(LoginRequest loginRequest) {

		ApiResponse<LoginResponse> apiResponse = new ApiResponse<LoginResponse>();

//		String url = serverUrl + Constants.REALM + realm + Constants.PROTOCOL_TOKEN;

		String username = loginRequest.getUsername();

		UserRepresentation representation = getUserResource(username);

		if (representation != null) {

			Boolean enabled = representation.isEnabled();
			if ((Boolean.FALSE.equals(enabled))) {
				return utility.errorResponse(apiResponse, HttpStatus.SERVICE_UNAVAILABLE, "user.disable.login.error");

			}

			if (Boolean.FALSE.equals(representation.isEmailVerified())) {
				return utility.errorResponse(apiResponse, HttpStatus.SERVICE_UNAVAILABLE,
						"email.verify.first.error.message");
			}

			Optional<User> findByUsername = userRepository.findByUsername(username);

			if (findByUsername.isPresent()) {
				User user = findByUsername.get();

				if (!Objects.equals(user.getIsEnable(), enabled)) {
					user.setIsEnable(enabled);

					userRepository.save(user);

				}
			}

		}

		LoginResponse response = genrateToken(loginRequest);

		response.getAccessToken();

		apiResponse.setData(response);
		apiResponse.setResult(true);
		apiResponse.setMessage("Login success !!");
		apiResponse.setStatus(HttpStatus.OK.value());
		return apiResponse;

		// return new ResponseEntity<>(response, HttpStatus.OK);
	}

	private LoginResponse genrateToken(LoginRequest loginRequest) {

		String url = serverUrl + Constants.REALM + realm + Constants.PROTOCOL_TOKEN;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add(Constants.CLIENT_ID, clientId);
		map.add(Constants.CLIENT_SECRET, clientSecret);
		map.add(Constants.GRANT_TYPE, Constants.PASSWORD);
		map.add(Constants.USERNAME, loginRequest.getUsername());
		map.add(Constants.PASSWORD, loginRequest.getPassword());

		return webClient.post().uri(url).headers(httpHeaders -> httpHeaders.addAll(headers))
				.body(BodyInserters.fromFormData(map)).retrieve()
				.onStatus(HttpStatusCode::is4xxClientError, clientResponse -> {
					if (clientResponse.statusCode() == HttpStatus.UNAUTHORIZED) {
						throw new BadApiRequestException("Invalid username or password");
					} else {
						throw new BadApiRequestException("An error occurred");
					}
				}).bodyToMono(LoginResponse.class).block();
	}

	private UserRepresentation getUserResource(String username) {
		RealmResource realm1 = keycloak.realm(realm);

		UsersResource users = realm1.users();

		List<UserRepresentation> representationList = users.search(username, true);

		return representationList.stream().findFirst().orElse(null);
	}
	
	
	private LoginResponse genrateTokenUsingRefreshToken(TokenRequest tokenRequest) {

		String url = serverUrl + Constants.REALM + realm + Constants.PROTOCOL_TOKEN;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add(Constants.CLIENT_ID, clientId);
		map.add(Constants.CLIENT_SECRET, clientSecret);
		map.add(Constants.GRANT_TYPE, Constants.REFRESH_TOKEN);
		map.add(Constants.REFRESH_TOKEN, tokenRequest.getRefreshToken());

		return webClient.post().uri(url).headers(httpHeaders -> httpHeaders.addAll(headers))
				.body(BodyInserters.fromFormData(map)).retrieve()
				.onStatus(HttpStatusCode::is4xxClientError, clientResponse -> {
					if (clientResponse.statusCode() == HttpStatus.UNAUTHORIZED) {
						throw new BadApiRequestException("Invalid username or password");
					} else {
						throw new BadApiRequestException("An error occurred");
					}
				}).bodyToMono(LoginResponse.class).block();
	}


	@Override
	public ApiResponse<LoginResponse> logout(String username) {

		ApiResponse<LoginResponse> response = new ApiResponse<>();
		RealmResource realmResource = keycloak.realm(realm);

		UserRepresentation representation = getUserResource(username);

		String userId = representation.getId();

		UserResource userResource = realmResource.users().get(userId);

		userResource.logout();

		List<UserSessionRepresentation> userSessions = userResource.getUserSessions();

		userSessions.clear();

		response.setResult(true);
		response.setMessage("Logout success !!");
		response.setStatus(HttpStatus.OK.value());
		return response;
	}

	@Override
	public ApiResponse<LoginResponse> generateTokenFromRefreshToken(TokenRequest tokenRequest) {
		ApiResponse<LoginResponse> apiResponse = new ApiResponse<>();

		LoginResponse response = genrateTokenUsingRefreshToken(tokenRequest);

		response.getAccessToken();
		apiResponse.setData(response);
		apiResponse.setResult(true);
		apiResponse.setMessage("Token generated successfully !!");
		apiResponse.setStatus(HttpStatus.OK.value());
		return apiResponse;
	}
}
