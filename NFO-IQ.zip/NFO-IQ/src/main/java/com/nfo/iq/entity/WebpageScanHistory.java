package com.nfo.iq.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "webpage_scan_history")
@Getter
@Setter
public class WebpageScanHistory extends BaseEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "webpage_url")
	private String webpageURL;
	
	@Column(name = "webpage_title")
	private String webpageTitle;
	
	@Column(name = "webpage_color")
	private String webpageColor;
	
	@Column(name = "is_blocked")
	public Boolean isBlocked;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	private User user;

}
