package com.nfo.iq.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DomainRequest {
	
	private String name;

	private String orgName;
	
	private String color;
}
