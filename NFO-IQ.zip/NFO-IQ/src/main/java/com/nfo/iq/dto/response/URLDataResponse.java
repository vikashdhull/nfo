package com.nfo.iq.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@JsonInclude(value = Include.NON_NULL)
@Getter
@Setter
public class URLDataResponse {
	
	private String organization;
	
	private String scanNotice;
	
	private String displayNotice;
	
	private String url;
	
	private String domainColor;
	
	private String domainExceptionColor;
	
	private String programFile;
	
	private boolean isTrusted = false;
	
	private String message;

}
