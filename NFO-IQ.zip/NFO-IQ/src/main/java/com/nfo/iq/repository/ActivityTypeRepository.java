package com.nfo.iq.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nfo.iq.entity.ActivityType;

public interface ActivityTypeRepository extends JpaRepository<ActivityType, Long> {
	
	
	Optional<ActivityType> findByName(String name);

}
