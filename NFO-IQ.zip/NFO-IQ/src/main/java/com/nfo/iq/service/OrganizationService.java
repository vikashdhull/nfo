package com.nfo.iq.service;

import java.util.List;

import com.nfo.iq.dto.request.OrganizationRequest;
import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.OrganizationResponse;
import com.nfo.iq.dto.response.PageableResponse;

public interface OrganizationService {

	ApiResponse<OrganizationResponse> createOrganization(OrganizationRequest organizationRequest);

	ApiResponse<OrganizationResponse> getOrganizationById(Long organizationId);

	ApiResponse<OrganizationResponse> updateOrganization(Long organizationId, OrganizationRequest organizationRequest);

	ApiResponse<List<OrganizationResponse>> getOrganizations();
	
	ApiResponse<OrganizationResponse> deleteOrganizationById(Long organizationId);

	ApiResponse<OrganizationResponse> removeOrganisations(RemoveAllRequest request);
	
	PageableResponse<OrganizationResponse> getOrganizationsWithPagination(int pageNumber, int pageSize, String sortBy,
			String sortDir);

}