package com.nfo.iq.service.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException.BadRequest;

import com.nfo.iq.dto.request.RemoveAllRequest;
import com.nfo.iq.dto.request.ScanDataRequest;
import com.nfo.iq.dto.request.URLRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.PageableResponse;
import com.nfo.iq.dto.response.URLDataResponse;
import com.nfo.iq.dto.response.URLResponse;
import com.nfo.iq.dto.response.WebpageScanHistoryResponse;
import com.nfo.iq.entity.BlockedURL;
import com.nfo.iq.entity.Domain;
import com.nfo.iq.entity.DomainExceptions;
import com.nfo.iq.entity.Organization;
import com.nfo.iq.entity.OrganizationType;
import com.nfo.iq.entity.ScanNotice;
import com.nfo.iq.entity.URLColor;
import com.nfo.iq.entity.User;
import com.nfo.iq.entity.UserControlURL;
import com.nfo.iq.entity.WebpageScanHistory;
import com.nfo.iq.repository.BlockedURLRepository;
import com.nfo.iq.repository.DomainExceptionRepository;
import com.nfo.iq.repository.DomainRepository;
import com.nfo.iq.repository.ScanNoticeRepository;
import com.nfo.iq.repository.URLColorRepository;
import com.nfo.iq.repository.UserControlURLRepository;
import com.nfo.iq.repository.UserRepository;
import com.nfo.iq.repository.WebpageScanHistoryRepo;
import com.nfo.iq.service.URLService;
import com.nfo.iq.utility.Constants;
import com.nfo.iq.utility.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class URLServiceImpl implements URLService {

	@Autowired
	private DomainRepository domainRepository;

	@Autowired
	private DomainExceptionRepository domainExceptionRepository;

//	@Autowired
//	private URLDomainColorRepository urlDomainColorRepository;

	@Autowired
	private URLColorRepository urlColorRepository;

	@Autowired
	private UserControlURLRepository userControlURLRepository;

	@Autowired
	private ScanNoticeRepository scanNoticeRepository;

	@Autowired
	private BlockedURLRepository blockedURLRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private WebpageScanHistoryRepo scanHistoryRepo;

	private static final String URL_VERIFY_MSG = "url.verify.success.message";

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility; 

	@Override
	public ApiResponse<URLDataResponse> verifyScanedURL(ScanDataRequest scanDataRequest, String userId) {

		ApiResponse<URLDataResponse> response = new ApiResponse<>();

		URLDataResponse urlResponse = new URLDataResponse();

		String type = scanDataRequest.getType();

		if (!Objects.equals(type, Constants.LINK)) {
			return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "invalid.url.message");
		}

		String url = scanDataRequest.getScanData();

		String host = findHostName(url);

		Optional<BlockedURL> findBlockedUrlByUser = blockedURLRepository.findBlockedUrl(userId, host);

		Optional<UserControlURL> findTrustedUrlByUser = userControlURLRepository.findTrustedUrl(userId, host);

		List<Domain> listOfDomain = domainRepository.findAll();

		Optional<Domain> optionalDomain = listOfDomain.stream().filter(s -> url.contains(s.getName())).findFirst();

		if (findBlockedUrlByUser.isPresent() && optionalDomain.isEmpty()) {
			return blockedUrlByUser(response, urlResponse, null, url, userId);
		}

		if (findTrustedUrlByUser.isPresent() && optionalDomain.isEmpty()) {
			return trustedUrlByUser(response, urlResponse, null, url, userId);
		}

		if (optionalDomain.isPresent()) {
			Domain domain = optionalDomain.get();
			return domainPresent(response, domain, urlResponse, url, userId, findBlockedUrlByUser,
					findTrustedUrlByUser);

		} else {

			String findColor = findColor(1003L);
			urlResponse.setOrganization(scanNoticeMessage(1001L));
			urlResponse.setDomainColor(findColor);
			urlResponse.setUrl(url);
			urlResponse.setScanNotice(scanNoticeMessage(1002L));
			urlResponse.setMessage(scanNoticeMessage(1003L));
			saveScannedUrlHistory(url, userId, findColor, false);
			response.setData(urlResponse);
			response.setResult(true);
			response.setMessage(env.getProperty(URL_VERIFY_MSG));
			response.setStatus(HttpStatus.OK.value());
			return response;

		}

	}

	private String findHostName(String urlString) {
		try {

			if (!urlString.startsWith("http://") && !urlString.startsWith("https://")) {
				urlString = "http://" + urlString;
			}

			URI uri = new URI(urlString);

			String host = uri.getHost();
			System.err.println("Host : "+host);

			return host.startsWith("www.") ? host.substring(4) : host;
		} catch (URISyntaxException e) {
			log.error("Error in findHostName method :" + e.getMessage());
			return urlString;

		}

	}
	
	
	ApiResponse<URLDataResponse> domainPresent(ApiResponse<URLDataResponse> response, Domain domain,
			URLDataResponse urlResponse, String url, String userId, Optional<BlockedURL> findBlockedUrlByUser,
			Optional<UserControlURL> findTrustedUrlByUser) {

		Organization organization = domain.getOrganization();

		String orgName = organization.getName();

		String domainColorName = domain.getUrlColor().getName(); 

		if (findBlockedUrlByUser.isPresent()) {

			return blockedUrlByUser(response, urlResponse, orgName, url, userId);

		}

		List<DomainExceptions> listOfDomainExp = domainExceptionRepository.findByDomainId(domain.getId());

		Optional<DomainExceptions> optionalDomainExp = listOfDomainExp.stream().filter(s -> url.contains(s.getUrl()))
				.findFirst();

		if (optionalDomainExp.isPresent()) {

			if (findTrustedUrlByUser.isPresent()) {
				return trustedUrlByUser(response, urlResponse, null, url, userId);
			}

			DomainExceptions domainExceptions = optionalDomainExp.get();

			OrganizationType organizationType = organization.getOrganizationType();

			return withDomainException(response, urlResponse, domainExceptions, orgName, url, organizationType,
					domainColorName, userId);

		} else {

			urlResponse.setOrganization(orgName);
			urlResponse.setDomainColor(domainColorName);
			urlResponse.setUrl(url);

			if (findTrustedUrlByUser.isPresent()) {
				urlResponse.setTrusted(true);
				urlResponse.setScanNotice("Saved by User as a Trusted URL");
			}
//			else {
//				urlResponse.setScanNotice("Saved by User as a Trusted URL");
//			}
			urlResponse.setMessage(scanNoticeMessage(1003L));
			saveScannedUrlHistory(url, userId, domainColorName, false);
			response.setData(urlResponse);
			response.setResult(true);
			response.setMessage(env.getProperty(URL_VERIFY_MSG));
			response.setStatus(HttpStatus.OK.value());
			return response;
		}

	}

	ApiResponse<URLDataResponse> blockedUrlByUser(ApiResponse<URLDataResponse> response, URLDataResponse urlResponse,
			String orgName, String url, String userId) {

		String findColor = findColor(1004L);

		urlResponse.setOrganization(orgName);
		urlResponse.setDomainColor(findColor);
		urlResponse.setUrl(url);
		urlResponse.setScanNotice("You have blocked this location");
		urlResponse.setMessage(scanNoticeMessage(1003L));

		saveScannedUrlHistory(url, userId, findColor, true);

		response.setData(urlResponse);
		response.setResult(true);
		response.setMessage(env.getProperty(URL_VERIFY_MSG));
		response.setStatus(HttpStatus.OK.value());
		return response;

	}

	ApiResponse<URLDataResponse> trustedUrlByUser(ApiResponse<URLDataResponse> response, URLDataResponse urlResponse,
			String orgName, String url, String userId) {

		String findColor = findColor(1001L);
		urlResponse.setOrganization(orgName);
		urlResponse.setDomainColor(findColor);
		urlResponse.setUrl(url);

		urlResponse.setScanNotice("Saved by User as a Trusted URL");
		urlResponse.setTrusted(true);
		urlResponse.setMessage(scanNoticeMessage(1003L));

		saveScannedUrlHistory(url, userId, findColor, false);
		response.setData(urlResponse);
		response.setResult(true);
		response.setMessage(env.getProperty(URL_VERIFY_MSG));
		response.setStatus(HttpStatus.OK.value());
		return response;

	}

	ApiResponse<URLDataResponse> withDomainException(ApiResponse<URLDataResponse> response, URLDataResponse urlResponse,
			DomainExceptions domainExceptions, String orgName, String url, OrganizationType organizationType,
			String domainColorName, String userId) {

		urlResponse.setOrganization(orgName);
		urlResponse.setDomainColor(domainColorName);
		urlResponse.setUrl(url);
		urlResponse.setDomainExceptionColor(domainExceptions.getUrlColor().getName());

		if (organizationType != null) {
			if (Constants.PAYMENT_APP.equals(organizationType.getName())) {
				urlResponse.setScanNotice(scanNoticeMessage(1004L));
			}
		} else if ("docs.google.com".equals(findHostName(url))) {
			urlResponse.setScanNotice(scanNoticeMessage(1007L));
		} else if (url.startsWith("https://www.google.com/search?q=")
				|| url.startsWith("https://google.com/search?q=")) {
			urlResponse.setScanNotice(scanNoticeMessage(1009L));
		} else if (url.startsWith("https://www.bing.com/search?q=") || url.startsWith("https://bing.com/search?q=")) {
			urlResponse.setScanNotice(scanNoticeMessage(1010L));
		} else {
			urlResponse.setScanNotice(scanNoticeMessage(null));
		}

		urlResponse.setMessage(scanNoticeMessage(1003L));

		saveScannedUrlHistory(url, userId, domainColorName, false);
		response.setData(urlResponse);
		response.setResult(true);
		response.setMessage(env.getProperty(URL_VERIFY_MSG));
		response.setStatus(HttpStatus.OK.value());
		return response;

	}

	private String scanNoticeMessage(Long id) {
		List<ScanNotice> findAll = scanNoticeRepository.findAll();

		Optional<ScanNotice> msgData = findAll.stream().filter(scanNotice -> Objects.equals(scanNotice.getId(), id))
				.findFirst();

		if (msgData.isPresent()) {
			return msgData.get().getName();
		} else {
			return null;
		}

	}

	private String findColor(Long id)

	{
		Optional<URLColor> findColorById = urlColorRepository.findById(id);

		if (findColorById.isPresent()) {

			URLColor urlColor = findColorById.get();

			return urlColor.getName();
		} else {
			return null;
		}

	}

	@Override
	public ApiResponse<URLResponse> saveTrustedUrl(URLRequest urlRequest, String userId) {

		String url = urlRequest.getUrl();

		String host = findHostName(url);

		Optional<UserControlURL> existUrl = userControlURLRepository.findTrustedUrl(userId, host);

		Optional<BlockedURL> blockedUrl = blockedURLRepository.findBlockedUrl(userId, host);

		ApiResponse<URLResponse> response = new ApiResponse<>();

		try {

			if (blockedUrl.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "url.control.save.error.message");
			}

			Optional<User> optionalUser = userRepository.findById(userId);

			if (existUrl.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "url.save.conflict.message");
			}

			if (optionalUser.isEmpty()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}

			UserControlURL controlURL = new UserControlURL();

			controlURL.setWebpageURL(urlRequest.getUrl());
			controlURL.setUser(optionalUser.get());
			userControlURLRepository.save(controlURL);

			URLResponse urlResponse = new URLResponse();

			urlResponse.setId(controlURL.getId());
			urlResponse.setUrl(controlURL.getWebpageURL());

			response.setData(urlResponse);
			response.setResult(true);
			response.setMessage(env.getProperty("url.save.success.message"));
			response.setStatus(HttpStatus.OK.value());
			return response;

		} catch (Exception e) {
			log.error("Exception in save Trusted URL operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<URLDataResponse> removeTrustedUrls(RemoveAllRequest request, String userId) {
		ApiResponse<URLDataResponse> response = new ApiResponse<>();

		List<Long> ids = request.getIds();
		// List<Long> ids
		try {
			Optional<User> optionalUser = userRepository.findById(userId);

			if (optionalUser.isEmpty()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}

			List<UserControlURL> urlsToRemove = userControlURLRepository.findByIdInAndUserId(ids, userId);

			if (!urlsToRemove.isEmpty()) {
				userControlURLRepository.deleteAll(urlsToRemove);

				response.setResult(true);
				response.setMessage(env.getProperty("url.remove.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "url.fetch.error.message");
			}
		} catch (Exception e) {
			log.error("Exception in remove Trusted URL operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<URLResponse> blockedUrl(URLRequest urlRequest, String userId) {

		String url = urlRequest.getUrl();

		String host = findHostName(url);
		Optional<BlockedURL> existUrl = blockedURLRepository.findBlockedUrl(userId, host);
		Optional<UserControlURL> existUrlinTrustedList = userControlURLRepository.findTrustedUrl(userId, host);

		ApiResponse<URLResponse> response = new ApiResponse<>();

		try {

			Optional<User> optionalUser = userRepository.findById(userId);

			if (existUrl.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "url.block.error.message");
			}

			if (optionalUser.isEmpty()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}

			if (existUrlinTrustedList.isPresent()) {
				UserControlURL userControlURL = existUrlinTrustedList.get();

				userControlURLRepository.delete(userControlURL);
			}

			BlockedURL blockedURL = new BlockedURL();

			blockedURL.setWebpageURL(urlRequest.getUrl());
			blockedURL.setUser(optionalUser.get());
			blockedURLRepository.save(blockedURL);

			response.setResult(true);
			response.setMessage(env.getProperty("url.block.success.message"));
			response.setStatus(HttpStatus.OK.value());
			return response;

		} catch (Exception e) {
			log.error("Exception in save Trusted URL operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<WebpageScanHistoryResponse> saveUrlHistory(URLRequest urlRequest, String userId) {

		ApiResponse<WebpageScanHistoryResponse> response = new ApiResponse<>();

		try {

			Optional<User> optionalUser = userRepository.findById(userId);

			if (optionalUser.isEmpty()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}

			WebpageScanHistory webpageScanHistory = new WebpageScanHistory();
			// if()
			// String title = Jsoup.connect(webpageUrl).get().title();
			webpageScanHistory.setWebpageURL(urlRequest.getUrl());
			webpageScanHistory.setWebpageTitle(null);
			webpageScanHistory.setUser(optionalUser.get());

			scanHistoryRepo.save(webpageScanHistory);

			WebpageScanHistoryResponse urlResponse = new WebpageScanHistoryResponse();

			urlResponse.setId(webpageScanHistory.getId());
			urlResponse.setWebpageURL(webpageScanHistory.getWebpageURL());
			// urlResponse.setWebpageTitle(webpageScanHistory.getWebpageTitle());
			urlResponse.setUser(webpageScanHistory.getUser().getEmail());
			urlResponse.setCreatedDate(webpageScanHistory.getCreatedDate());

			response.setData(urlResponse);
			response.setResult(true);
			response.setMessage(env.getProperty("url.save.success.message"));
			response.setStatus(HttpStatus.OK.value());
			return response;

		} catch (Exception e) {
			log.error("Exception in save save Url History operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	public ApiResponse<WebpageScanHistoryResponse> saveScannedUrlHistory(String webpageUrl, String userId, String color,
			Boolean isBlocked) {

		ApiResponse<WebpageScanHistoryResponse> response = new ApiResponse<>();

		try {

			Optional<User> optionalUser = userRepository.findById(userId);

			if (optionalUser.isEmpty()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}

			WebpageScanHistory webpageScanHistory = new WebpageScanHistory();
			// if()
			// String title = Jsoup.connect(webpageUrl).get().title();
			webpageScanHistory.setWebpageURL(webpageUrl);
			webpageScanHistory.setWebpageTitle(null);
			webpageScanHistory.setUser(optionalUser.get());
			webpageScanHistory.setWebpageColor(color);
			webpageScanHistory.setIsBlocked(isBlocked);

			scanHistoryRepo.save(webpageScanHistory);

			WebpageScanHistoryResponse urlResponse = new WebpageScanHistoryResponse();

			urlResponse.setId(webpageScanHistory.getId());
			urlResponse.setWebpageURL(webpageScanHistory.getWebpageURL());
			// urlResponse.setWebpageTitle(webpageScanHistory.getWebpageTitle());
			urlResponse.setWebpageColor(webpageScanHistory.getWebpageColor());
			urlResponse.setIsBlocked(webpageScanHistory.getIsBlocked());
			urlResponse.setUser(webpageScanHistory.getUser().getEmail());
			urlResponse.setCreatedDate(webpageScanHistory.getCreatedDate());

			response.setData(urlResponse);
			response.setResult(true);
			response.setMessage(env.getProperty("url.save.success.message"));
			response.setStatus(HttpStatus.OK.value());
			return response;

		} catch (Exception e) {
			log.error("Exception in save save Url History operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<URLResponse> unblockedUrl(URLRequest urlRequest, String userId) {
		Optional<BlockedURL> existUrl = blockedURLRepository.findByUserIdAndWebpageURL(userId, urlRequest.getUrl());
		ApiResponse<URLResponse> response = new ApiResponse<>();

		try {

			Optional<User> optionalUser = userRepository.findById(userId);

			if (optionalUser.isEmpty()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "user.fetch.error.message");
			}
			if (existUrl.isPresent()) {

				BlockedURL blockedURL = existUrl.get();

				blockedURLRepository.delete(blockedURL);

				response.setResult(true);
				response.setMessage(env.getProperty("url.un.block.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "url.fetch.error.message");
			}

		} catch (Exception e) {
			log.error("Exception in Un-Blocked URL operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public PageableResponse<URLResponse> getAllTrustedURL(String userId, int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<UserControlURL> page = userControlURLRepository.findByUserId(userId, pageable);

		PageableResponse<URLResponse> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {

				List<URLResponse> urllist = page.stream().map(url -> {
					URLResponse urlList = new URLResponse();
					urlList.setId(url.getId());
					urlList.setUrl(url.getWebpageURL());
					urlList.setCreatedDate(url.getCreatedDate());
					return urlList;
				}).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(urllist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, "url.fetch.error.message");
			}
		} catch (BadRequest exp) {
			log.error("Exception Occured in getAllTrustedURL Method present in URLServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public PageableResponse<WebpageScanHistoryResponse> getAllScannedURL(String userId, boolean distinct,
			int pageNumber, int pageSize, String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<WebpageScanHistory> page = scanHistoryRepo.findByUserId(userId, pageable);
		PageableResponse<WebpageScanHistoryResponse> response = new PageableResponse<>();
		try {
			if (!page.isEmpty()) {

				if (!distinct) {
					List<WebpageScanHistoryResponse> urllist = page.stream().map(url -> {
						WebpageScanHistoryResponse urlList = new WebpageScanHistoryResponse();
						urlList.setId(url.getId());
						urlList.setWebpageURL(url.getWebpageURL());
						urlList.setWebpageColor(url.getWebpageColor());
						urlList.setIsBlocked(url.getIsBlocked());
						// urlList.setWebpageTitle(url.getWebpageTitle());
						urlList.setCreatedDate(url.getCreatedDate());
						return urlList;
					}).toList();

					long totalElements = page.getTotalElements();
					int totalPages = page.getTotalPages();
					response.setData(urllist);
					response.setPageNumber(page.getNumber());
					response.setPageSize(page.getSize());
					response.setTotalElements(totalElements);
					response.setTotalPages(totalPages);
					response.setLastPage(page.isLast());
					response.setMessage(env.getProperty("record.fetch.success.message"));
					response.setResult(true);
					response.setStatus(HttpStatus.OK.value());
					return response;
				} else {
					Set<String> uniqueURLs = new HashSet<>();
					List<WebpageScanHistoryResponse> urllist = page.stream()
							.filter(url -> uniqueURLs.add(url.getWebpageURL())).map(url -> {
								WebpageScanHistoryResponse urlList = new WebpageScanHistoryResponse();
								urlList.setId(url.getId());
								urlList.setWebpageURL(url.getWebpageURL());
								urlList.setWebpageColor(url.getWebpageColor());
								urlList.setIsBlocked(url.getIsBlocked());
								urlList.setCreatedDate(url.getCreatedDate());
								return urlList;
							}).toList();

					int totalPages = page.getTotalPages();
					response.setData(urllist);
					response.setPageNumber(page.getNumber());
					response.setPageSize(page.getSize());
					response.setTotalElements(urllist.size());
					response.setTotalPages(totalPages);
					response.setLastPage(page.isLast());
					response.setMessage(env.getProperty("record.fetch.success.message"));
					response.setResult(true);
					response.setStatus(HttpStatus.OK.value());
					return response;
				}

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, "url.fetch.error.message");
			}
		}

		catch (BadRequest exp) {
			log.error("Exception Occured in getAllScannedURL Method present in URLServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}
}
