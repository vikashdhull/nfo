package com.nfo.iq.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizationTypeRequest {

	private String name;

}
