package com.nfo.iq.service;

import org.keycloak.representations.idm.UserRepresentation;

import com.nfo.iq.dto.request.UserRequest;
import com.nfo.iq.dto.response.ApiResponse;
import com.nfo.iq.dto.response.SubcriptionDetailsResponse;
import com.nfo.iq.dto.response.UserResponse;

public interface UserService {
	
	ApiResponse<UserResponse> createUser(UserRequest userRequest);
	
	UserRepresentation getUsersById(String userId);
	
	ApiResponse<UserResponse> getUserById(String userId);
	
	ApiResponse<UserResponse> forgotPassword(String username);
	
	ApiResponse<UserResponse> updateEmailById(String userId, String email);
	
	ApiResponse<UserResponse> updatePassword(String userId, String password);
	
	ApiResponse<UserResponse> updateMobile(String userId, String mobile);
	
	ApiResponse<UserResponse> disableUser(String userId);
	
	ApiResponse<UserResponse> enableUser(String userId);
	
	ApiResponse<SubcriptionDetailsResponse> getUserSubcriptionDetails(String userId);

}
