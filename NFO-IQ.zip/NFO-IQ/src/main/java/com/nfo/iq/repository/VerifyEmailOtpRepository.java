package com.nfo.iq.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nfo.iq.entity.VerifyEmailOtp;

public interface VerifyEmailOtpRepository extends JpaRepository<VerifyEmailOtp, Long> {
	
	Optional<VerifyEmailOtp> findByEmail(String email);
	
	Optional<VerifyEmailOtp> findByOtpAndEmail(String otp, String email);

}
