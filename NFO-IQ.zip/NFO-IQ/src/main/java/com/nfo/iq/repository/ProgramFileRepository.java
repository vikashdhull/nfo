package com.nfo.iq.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nfo.iq.entity.ProgramFile;

public interface ProgramFileRepository extends JpaRepository<ProgramFile, Long> {

}
