package com.nfo.iq.dto.response;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(value = Include.NON_NULL)
public class OrganizationResponse {
	
	private Long id;
	
	private String orgName;
	
	private String orgType;
	
	private String streetAddress;

	private String city;

	private String state;
	
	private String country;

	private int zipCode;
	
	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}

