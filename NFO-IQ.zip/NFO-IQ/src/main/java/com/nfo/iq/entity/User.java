package com.nfo.iq.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.nfo.iq.utility.SubscriptionType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "users")
@Getter
@Setter
@ToString
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Column(name = "username", unique = true, length = 100)
	private String username;

	@Column(name = "email", unique = true, length = 100)
	private String email;
	
	@Column(name = "is_email_verified")
	private Boolean isEmailVerified;

	@Column(name = "mobile_number", unique = true)
	private String mobileNumber;
	
	@Column(name = "is_enable")
	private Boolean isEnable;
	
	@Enumerated(EnumType.STRING)
	private SubscriptionType subscriptionType;
	
	@Column(name = "payment_status")
	private Boolean paymentStatus;
	
	@Column(name = "subscription_start_date")
	private LocalDate subscriptionStartDate;

	@Column(name = "created_date", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;
}
